import {
  StyleSheet,
  Dimensions,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  Image,
  Text,
  View,
} from 'react-native';
import React, {useState,useEffect} from 'react';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const {height, width} = Dimensions.get('window');
const Login = (props) => {

  const [email, setEmail] = useState('');
  const [errorEmail, setErrorEmail] = useState('');

  const [password, setPassword] = useState('');
  const [errorPassword, setErrorPassword] = useState('');

  const emailValidate = email => {
    var Regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email === '' || email === undefined || email === null) {
      setErrorEmail('please enter email');
    } else if (!Regex.test(email)) {
      setErrorEmail('Please enter valid email');
    } else {
      setErrorEmail(null);
    }
  };

  const passwordValidate = password => {
    var Regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    if (password === '' || password === undefined || password === null) {
      setErrorPassword('Please enter password');
    } else if (!Regex.test(password)) {
      setErrorPassword('Please enter valid password');
    } else {
      setErrorPassword(null);
    }
  };

  const validate = () => {
    var Rgx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var Rgxc =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    const flag = true;
    if (email === '') {
      setErrorEmail('Please enter email');
      return !flag;
    }
    // if(!Rgx.test(email)){
    //     setErrorEmail('please enter vald email');
    //     // return !flag;
    // }
    if (password === '') {
      setErrorPassword('Please enter password');
      return !flag;
    }
    if(!Rgxc.test(password)){
        setErrorPassword('please enter valid password');
        return !flag;
    }
    return flag;
  };

  const onSubmit = () => {
    if (validate()) {
      // alert('Sussessful')
      props.navigation.navigate('Api');
    // LoginApi();
    } else {
      alert('Something went wrong');
    }
  };

  const LoginApi = () => {
    axios({
      method: 'post',
      url: 'http://172.16.1.132:1909/api/v1/user/login',
      data: {
        email: email,
        password: password,
      },
      headers: {'content-type': 'application/json'},
    })
      .then(async response => {
        if (response.data.responseCode === 200) {
          console.log('====== token ======', response);
          await AsyncStorage.setItem('token', response?.data?.result?.token);
          props.navigation.navigate('Home');
        } else {
          alert('Something went worng');
        }
      })
      .catch(err => {
        console.log('====Login catch error=====', err);
      });
  };

  
  return (
    <View>
      <SafeAreaView>
        <View style={styles.img}>
          <Image
            style={{height: 250, width: 250, resizeMode: 'contain'}}
            source={require('../../images/Splash.jpeg')}
          />
        </View>
        <View style={styles.txt}>
          <Text style={{fontSize: 25, marginLeft: 17, fontWeight: 'bold'}}>
            Welcome to Knab79
          </Text>
          <Text style={{fontSize: 18, marginLeft: 45, color: '#868783'}}>
            Keep your data safe!
          </Text>
        </View>

        <View style={{height:height*0.13,justifyContent:'center', }}>
        <View style={styles.txtinput}>
        <TextInput
          style={styles.input}
          placeholder="Enter your email "
          placeholderTextColor={'#868783'}
          keyboardType="email-address"
          onChangeText={text => {
            setEmail(text), emailValidate(text);
          }}
        />
        </View>
      {errorEmail !== null ? (
        <View
          style={{
            height: '20%',
            width: '80%',
             alignSelf:'center',
             justifyContent:'center',
            // backgroundColor: 'green',
          }}>
          <Text style={{color: 'red', fontSize: 16}}>{errorEmail}</Text>
        </View>
      ) : null}
      
        </View>
       
        <View style={{height:height*0.13,justifyContent:'center', }}>
        <View style={styles.txtinput}>
        <TextInput
          style={styles.input}
          placeholder="Enter your Password "
          placeholderTextColor={'#868783'}
          keyboardType="email-address"
          onChangeText={text => {
            setPassword(text), passwordValidate(text);
          }}
        />
        </View>
      {errorPassword !== null ? (
        <View
          style={{
            height: '20%',
            width: '80%',
             alignSelf:'center',
             justifyContent:'center',
            // backgroundColor: 'green',
          }}>
          <Text style={{color: 'red', fontSize: 16}}>{errorPassword}</Text>
        </View>
      ) : null}
      
        </View>
       

       <View style={styles.btn}>
       <TouchableOpacity onPress={() => onSubmit() }>
       <View style={styles.touchable}>
         <Text style={styles.ttt}>
           Login
         </Text>
       </View>
     </TouchableOpacity>
       </View>

        <TouchableOpacity onPress={() => alert('Something went wrong')}>
          <Text style={{fontSize: 20, color: '#83d4d0', alignSelf: 'center'}}>
            Forgot Passwoed?
          </Text>
        </TouchableOpacity>

        <View style={styles.text}>
          <Text style={{fontSize: 18, alignSelf: 'center'}}>
            Don't have an account?
          </Text>
         <TouchableOpacity onPress={() => props.navigation.navigate('Signup')}>
         <Text style={{fontSize: 20, alignSelf: 'center', color: '#83d4d0'}}>
         Sign UP
       </Text>
         </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
};

export default Login;

const styles = StyleSheet.create({
  img: {
    height: height * 0.25,
    width: width * 0.7,
    alignSelf: 'center',
  },
  txt: {
    height: height * 0.08,
    width: width * 0.8,
    justifyContent: 'center',
    justifyContent: 'space-between',
    alignSelf: 'center',
    
  },
  txtinput: {
    height: height * 0.08,
    width: width * 0.8,
    backgroundColor: '#eaebe6',
    justifyContent: 'center',
    padding: 10,
    alignSelf: 'center',
   shadowOpacity:.5,
   
   shadowColor:"#000000",
    justifyContent: 'space-between',
  },
  textinput: {
    height: height * 0.08,
    width: width * 0.8,
    backgroundColor: '#eaebe6',
    shadowOpacity:.5,
    
    shadowColor:"#000000",
  },
  input: {
    fontSize: 19,
    color: '#141414',
    padding: 10,
  },
  touchable: {
    height: height * 0.08,
    width: width * 0.8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#6cd4ce',
    shadowOpacity:.5,
    
    shadowColor:"#000000",
    borderRadius:28
   
  },
  btn:{
    height: height * 0.13,
    width: width * 0.8,
    justifyContent: 'center',
    alignSelf: 'center',
    borderRadius: 37,

  },
  text: {
    height: height * 0.032,
    width: width * 0.8,
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    marginVertical: 35,
    
  },
  ttt: {
    fontSize: 22,
     color: 'white',
      fontWeight: 'bold'
  }
});



// ************* New Code *********************
// import {
//     StyleSheet,
//     Text,
//     SafeAreaView,
//     TouchableOpacity,
//     View,
//     Dimensions,
//     Image,
//     TextInput,
//   } from 'react-native';
//   import React, {useState} from 'react';
//   import axios from 'axios';
//   import AsyncStorage from '@react-native-async-storage/async-storage';
//   const {height, width} = Dimensions.get('window');
  
//   const Login = props => {
//     // *********** Step-1 ***********
//     const [Email, setEmail] = useState('');
  
//     const [errorEmail, setErrorEmail] = useState(null);
  
//     const [Password, setPassword] = useState('');
//     const [errorPassword, setErrorPassword] = useState(null);
  
//     // Step-2
//     const _emailvalidate = mail => {
//       var emailRegex =
//         /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
//       if (mail === '') {
//         setErrorEmail('*Please enter email');
//       } else if (!emailRegex.test(mail)) {
//         setErrorEmail('*Please enter valid email');
//       } else {
//         setErrorEmail(null);
//       }
//     };
  
//     const _passwordvalidate = pass => {
//       var passwordRegex =
//         /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
//       if (pass === '') {
//         setErrorPassword('*Please enter password.');
//       } else if (/([A-Z]+)/g.test(pass) && pass.length < 8) {
//         setErrorPassword('*Please enter  valid password');
//       } else if (!passwordRegex.test(pass)) {
//         setErrorPassword('*Please enter valid password.');
//       } else {
//         setErrorPassword(null);
//       }
//     };
  
//     // Step-3
//     const validate = () => {
//       let flag = true;
//       if (Email === '') {
//         setErrorEmail('*Please enter email--.');
//         // flag = false;
//         return !flag;
//       }
//       if (Password === '') {
//         setErrorPassword('*Please enter password--.');
//         // flag = false;
//         return !flag;
//       }
//       return flag;
//     };
  
//     // step-4
//     const onSubmit = () => {
//       if (validate()) {
//         LoginApi();
//       } else {
//         alert('something went wrong');
//       }
//     };
  
//     //* *****   Login API ******* */
  
//     const LoginApi = () => {
//       axios({
//         method: 'post',
//         url: 'http://172.16.1.132:1909/api/v1/user/login',
//         data: {
//           email: Email,
//           password: Password,
//         },
//         headers: {'content-type': 'application/json'},
//       })
//         .then(async response => {
//           if (response.data.responseCode === 200) {
//             console.log('====== token ======', response);
//             await AsyncStorage.setItem('token', response?.data?.result?.token);
//             props.navigation.navigate('BottomTab');
//           } else {
//             alert('Something went worng');
//           }
//         })
//         .catch(err => {
//           console.log('====Login catch error=====', err);
//         });
//     };
  
//     return (
//       <SafeAreaView>
//         <View style={styles.maincontainer}>
//           <Image
//             source={require('../../assets/image/logo1.jpeg')}
//             style={{height: 150, width: 300}}
//           />
//         </View>
//         <View style={styles.textcontainer}>
//           <Text style={{color: 'black', fontSize: 20}}>Welcome to knab79</Text>
//         </View>
//         <View style={styles.text}>
//           <Text style={{color: 'grey', fontWeight: 'bold'}}>
//             Keep your data safe!
//           </Text>
//         </View>
//         <View style={styles.emailtextinput}>
//           <View style={styles.textinput}>
//             <TextInput
//               placeholder="Enter email or phone number"
//               placeholderTextColor={'grey'}
//               keyboardType="email-address"
//               maxLength={60}
//               onChangeText={txt => {
//                 setEmail(txt), _emailvalidate(txt);
//               }}
//               style={{fontSize: 15, color: 'green'}}
//             />
//           </View>
//         </View>
  
//         {errorEmail !== null ? (
//           <View
//             style={{
//               height: height * 0.02,
//               width: width * 0.9,
//               //justifyContent:'center',
//               alignSelf: 'center',
//               // backgroundColor:'blue'
//             }}>
//             <Text style={{color: 'red', fontSize: 17}}>{errorEmail}</Text>
//           </View>
//         ) : null}
  
//         <View style={styles.passtextinput}>
//           <View style={styles.textinput}>
//             <TextInput
//               placeholder="Enter password"
//               placeholderTextColor={'grey'}
//               keyboardType="default"
//               secureTextEntry
//               maxLength={16}
//               onChangeText={txt => {
//                 setPassword(txt), _passwordvalidate(txt);
//               }}
//               style={{fontSize: 15, color: 'green'}}
//             />
//           </View>
//         </View>
//         {errorPassword !== null ? (
//           <View
//             style={{
//               height: height * 0.023,
//               width: width * 0.9,
//               alignSelf: 'center',
//             }}>
//             <Text style={{color: 'red', fontSize: 17}}>{errorPassword}</Text>
//           </View>
//         ) : null}
//         <View
//           style={{
//             height: height * 0.15,
//             width: width * 1,
//             justifyContent: 'center',
//             alignItems: 'center',
//             // backgroundColor:'blue'
//           }}>
//           <TouchableOpacity onPress={() => onSubmit()}>
//             <View
//               style={{
//                 height: height * 0.07,
//                 width: width * 0.9,
//                 borderWidth: 1,
//                 borderRadius: 35,
//                 backgroundColor: 'green',
//                 justifyContent: 'center',
//                 alignItems: 'center',
//               }}>
//               <Text style={{color: 'white', fontSize: 18}}>Login</Text>
//             </View>
//           </TouchableOpacity>
//         </View>
  
//         <View
//           style={{
//             height: height * 0.08,
//             width: width * 1,
//             justifyContent: 'center',
//             alignItems: 'center',
//             // backgroundColor:'red'
//           }}>
//           <TouchableOpacity
//             onPress={() => props.navigation.navigate('ForgotPassword')}>
//             <Text style={{color: 'green', fontSize: 15}}>Forgot password?</Text>
//           </TouchableOpacity>
//         </View>
  
//         <View
//           style={{
//             height: height * 0.14,
//             width: width * 1,
//             justifyContent: 'center',
//             alignItems: 'center',
//             flexDirection: 'row',
//             //backgroundColor:'blue'
//           }}>
//           <Text>Don't have an account?</Text>
//           <TouchableOpacity onPress={() => props.navigation.navigate('SignUp')}>
//             <Text style={{color: 'green', fontSize: 15}}>Sign UP</Text>
//           </TouchableOpacity>
//         </View>
//       </SafeAreaView>
//     );
//   };
  
//   export default Login;
  
//   const styles = StyleSheet.create({
//     maincontainer: {
//       height: height * 0.25,
//       width: width * 1,
//       justifyContent: 'center',
//       alignItems: 'center',
//       //backgroundColor:'green'
//     },
//     textcontainer: {
//       height: height * 0.04,
//       width: width * 1,
//       justifyContent: 'center',
//       alignItems: 'center',
//       //backgroundColor:'blue'
//     },
//     text: {
//       height: height * 0.04,
//       width: width * 1,
//       justifyContent: 'center',
//       alignItems: 'center',
//       //backgroundColor:'green'
//     },
//     emailtextinput: {
//       height: height * 0.08,
//       width: width * 1,
//       justifyContent: 'center',
//       alignItems: 'center',
//       //backgroundColor: 'green',
//     },
//     textinput: {
//       height: height * 0.07,
//       width: width * 0.9,
//       borderWidth: 2,
//       borderRadius: 10,
//       backgroundColor: 'pink',
//       justifyContent: 'center',
//       //alignItems:'center',
//       padding: 15,
//     },
//     passtextinput: {
//       height: height * 0.08,
//       width: width * 1,
//       justifyContent: 'center',
//       alignItems: 'center',
//       // backgroundColor: 'black',
//     },
//   });