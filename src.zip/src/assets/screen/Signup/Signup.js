import {
  StyleSheet,
  Dimensions,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  SafeAreaView,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {Dropdown} from 'react-native-material-dropdown';

const {height, width} = Dimensions.get('window');
const data = [
  {
    value: 'Admin',
  },
  {
    value: 'Trainee',
  },
  {
    value: 'Employee',
  },
];
const Signup = props => {
  const [name, setName] = useState('');
  const [errorname, setErrorName] = useState('');

  const [email, setEmail] = useState('');
  const [errorEmail, setErrorEmail] = useState('');

  const [password, setPassword] = useState('');
  const [errorPassword, setErrorPassword] = useState('');

  const [phone, setPhone] = useState('');
  const [errorPhone, setErrorPhone] = useState('');

  const nameValidate = name => {
    var Regex =
      /^(([A-Za-z]+[\-\']?)*([A-Za-z]+)?\s)+([A-Za-z]+[\-\']?)*([A-Za-z]+)?$/;
    if (name === '' || name === undefined || name === null) {
      setErrorName('please enter name');
    } else if (!Regex.test(name)) {
      setErrorName('please enter valid name');
    } else {
      setErrorName(null);
    }
  };

  const emailValidate = email => {
    var Regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email === '' || email === undefined || email === null) {
      setErrorEmail('please enter email');
    } else if (!Regex.test(email)) {
      setErrorEmail('Please enter valid email');
    } else {
      setErrorEmail(null);
    }
  };

  const passwordValidate = password => {
    var Regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    if (password === '' || password === undefined || password === null) {
      setErrorPassword('please enter password');
    } else if (!Regex.test(password)) {
      setErrorPassword('please enter valid password');
    } else {
      setErrorPassword(null);
    }
  };

  const phoneValidate = phone => {
    var Regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (phone === '' || phone === undefined || phone === null) {
      setErrorPhone('please enter phone number');
    } else if (!Regex.test(phone)) {
      setErrorPhone('please enter valid number');
    } else {
      setErrorPhone(null);
    }
  };

  const validate = () => {
    const flag = true;
    if (name === '') {
      setErrorName('please enter name')
      return !flag;
    }
    if (email === '') {
      setErrorEmail('Please enter email');
      return !flag;
    }
    if (password === '') {
      setErrorPassword('please enter password');
      return !flag;
    }
    if (phone === '') {
      setErrorPhone('please enter phone number')
      return !flag;
    }
    return flag;
  };

  const onSubmit = () => {
    if (validate()) {
      // alert('Sussessful')
      props.navigation.navigate('Login');
    } else {
      alert('Something went wrong');
    }
  };
  return (
    <SafeAreaView>
      <View style={styles.maincontainer}>
        <View style={styles.arrowcontainer}>
          <TouchableOpacity onPress={()=> props.navigation.navigate('Login')}>
            <View style={styles.arrow}>
              <Image
                style={{height: 55, width: 55, borderRadius:20}}
                source={require('../../images/arr.jpeg')}
              />
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.signup}>
          <Text style={{fontSize: 24, fontWeight: 'bold'}}>Sign Up</Text>
        </View>
        <View style={styles.ttcontainer}>
          <View style={styles.con}>
            <View style={styles.inputcontainer}>
              <TextInput
                style={{fontSize: 16, color: 'black'}}
                placeholder="Enter Full Name"
                placeholderTextColor={'#b6b4b8'}
                keyboardType="default"
                maxLength={18}
                onChangeText={text => {
                  setName(text), nameValidate(text);
                }}
              />
            </View>
            {errorname !== null ? (
              <View
                style={{
                  height: '29%',
                  width: '80%',
                }}>
                <Text style={{color: 'red', fontSize: 16,}}>{errorname}</Text>
              </View>
            ) : null}
          </View>

          <View style={styles.con}>
            <View style={styles.pickercontainer}>
              <Dropdown label="Select User Type" data={data} />
            </View>
          </View>

          <View style={styles.con}>
            <View style={styles.inputcontainer}>
              <TextInput
                style={{fontSize: 16, color: 'black'}}
                placeholder="Enter email address"
                placeholderTextColor={'#b6b4b8'}
                keyboardType="email-address"
                maxLength={24}
                onChangeText={text => {
                  setEmail(text), emailValidate(text);
                }}
              />
            </View>
            {errorEmail !== null ? (
              <View
                style={{
                  height: '30%',
                  width: '80%',
                  //  alignSelf:'center',
                  // backgroundColor: 'green',
                }}>
                <Text style={{color: 'red', fontSize: 17}}>{errorEmail}</Text>
              </View>
            ) : null}
          </View>

          <View style={styles.con}>
            <View style={styles.inputcontainer}>
              <TextInput
                style={{fontSize: 16, color: 'black'}}
                placeholder="Enter Password"
                placeholderTextColor={'#b6b4b8'}
                keyboardType="default"
                secureTextEntry={true}
                maxLength={18}
                onChangeText={text => {
                  setPassword(text), passwordValidate(text);
                }}
              />
            </View>
            {errorPassword !== null ? (
              <View
                style={{
                  height: '25%',
                  width: '80%',
                  // alignSelf:'center',
                  // backgroundColor: 'green',
                }}>
                <Text style={{color: 'red', fontSize: 16}}>
                  {errorPassword}
                </Text>
              </View>
            ) : null}
          </View>
          <View style={styles.con}>
            <View style={styles.inputcontainer}>
              <TextInput
                style={{fontSize: 16, color: 'black'}}
                placeholder="Phone Number"
                placeholderTextColor={'#b6b4b8'}
                keyboardType="number-pad"
                maxLength={10}
                onChangeText={text => {
                  setPhone(text), phoneValidate(text);
                }}
              />
            </View>
            {errorPhone !== null ? (
              <View
                style={{
                  height: '30%',
                  width: '80%',
                  // alignSelf:'center',
                  // backgroundColor: 'green',
                }}>
                <Text style={{color: 'red', fontSize: 16}}>{errorPhone}</Text>
              </View>
            ) : null}
          </View>
        </View>
        <View style={styles.btncontainer}>
          <TouchableOpacity onPress={() => onSubmit()}>
            <View style={styles.btn}>
              <Text style={{fontSize: 22, color: 'white', fontWeight: 'bold'}}>

                Register
              </Text>
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.lcontainer}>
          <View style={styles.start}>
            <Text style={{fontSize: 18}}>have an account?</Text>
          </View>
          <View style={styles.end}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate('Login')}>
              <Text style={{fontSize: 18, color: 'cyan'}}>Login</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Signup;

const styles = StyleSheet.create({
  maincontainer: {
    height: height * 1,
    width: width * 1,
    backgroundColor:'#fff'
  },
  arrowcontainer: {
    height: height * 0.13,
    width: width * 0.85,
    // backgroundColor:'cyan',
    alignSelf: 'center',
    justifyContent: 'center',
  },
  arrow: {
    height: height * 0.06,
    width: width * 0.12,
    backgroundColor: 'cyan',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
  },
  signup: {
    height: height * 0.09,
    width: width * 0.85,
    // backgroundColor:'cyan',
    alignSelf: 'center',
    justifyContent: 'center',
  },
  inputcontainer: {
    height: height * 0.067,
    width: width * 0.85,
    // backgroundColor: '#e3e3e3',
    justifyContent: 'flex-end',
    padding: 5,
    alignSelf: 'center',
    borderBottomWidth:1,
    // borderRadius: 14,
  },
  con: {
    height: height * 0.1,
    width: width * 0.85,
    // backgroundColor:'cyan'
  },
  ttcontainer: {
    height: height * 0.5,
    width: width * 0.85,
    alignSelf: 'center',
    // justifyContent:'space-between',
    // backgroundColor:'pink'
  },
  pickercontainer: {
    height: height * 0.067,
    width: width * 0.85,
    // backgroundColor: '#e3e3e3',
    justifyContent: 'center',
    padding: 5,
    borderBottomWidth:1,
    alignSelf: 'center',
    // borderRadius: 14,
  },
  btncontainer: {
    height: height * 0.12,
    width: width * 0.85,
    // backgroundColor:'black',
    alignSelf: 'center',
    justifyContent: 'center',
  },
  btn: {
    height: height * 0.074,
    width: width * 0.85,
    backgroundColor: 'cyan',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 43,
  },
  lcontainer: {
    height: height * 0.07,
    width: width * 0.85,
    // backgroundColor:'green',
    alignSelf: 'center',
    alignItems: 'flex-end',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  start: {
    height: height * 0.05,
    width: width * 0.37,
    //   backgroundColor:'cyan',
  },
  end: {
    height: height * 0.05,
    width: width * 0.2,
    //   backgroundColor:'red'
  },
});
