import {
  StyleSheet,
  Text,
  SafeAreaView,
  TextInput,
  Dimensions,
  TouchableOpacity,
  Image,
  View,
} from 'react-native';
import React,{useState} from 'react';
import { Dropdown } from 'react-native-material-dropdown';

const {height, width} = Dimensions.get('window');

const data = [
  {
    value: '+91',
  },
  {
    value: '+91',
  },
  {
    value: '+91',
  },
];
const Profile = (props) => {
  const [name, setName] = useState('');
  const [errorname, setErrorName] = useState('');

  const [email, setEmail] = useState('');
  const [errorEmail, setErrorEmail] = useState('');

  const [phone, setPhone] = useState('');
  const [errorPhone, setErrorPhone] = useState('');

  const nameValidate = name => {
    var Regex =
      /^(([A-Za-z]+[\-\']?)*([A-Za-z]+)?\s)+([A-Za-z]+[\-\']?)*([A-Za-z]+)?$/;
    if (name === '' || name === undefined || name === null) {
      setErrorName('please enter name');
    } else if (!Regex.test(name)) {
      setErrorName('please enter valid name');
    } else {
      setErrorName(null);
    }
  };

  const emailValidate = email => {
    var Regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email === '' || email === undefined || email === null) {
      setErrorEmail('please enter email');
    } else if (!Regex.test(email)) {
      setErrorEmail('Please enter valid email');
    } else {
      setErrorEmail(null);
    }
  };

  const phoneValidate = phone => {
    var Regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (phone === '' || phone === undefined || phone === null) {
      setErrorPhone('please enter phone number');
    } else if (!Regex.test(phone)) {
      setErrorPhone('please enter valid number');
    } else {
      setErrorPhone(null);
    }
  };

  const validate = () => {
    var Regx =
      /^(([A-Za-z]+[\-\']?)*([A-Za-z]+)?\s)+([A-Za-z]+[\-\']?)*([A-Za-z]+)?$/;
      var Regx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      var Regx = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    const flag = true;
    if (name === '') {
      setErrorName('please enter name')
      return !flag;
    }
    if(!Regx.test(name)){
      setErrorName('please enter valid name')
    }
    if (email === '') {
      setErrorEmail('Please enter email');
      return !flag;
    }
    if(!Regx.test(email)){
      setErrorEmail('plesae enter valid email')
    }
    if (phone === '') {
      setErrorPhone('please enter phone number')
      return !flag;
    }
    if(!Regx.test(phone)){
      setErrorPhone('please enter valid number')
    }
    return flag;
  };

  const onSubmit = () => {
    if (validate()) {
      // alert('Sussessful')
      // props.navigation.navigate('Home');
    } else {
      alert('Something went wrong');
    }
  };
  return (
    <SafeAreaView>
      <View style={styles.main}>
        <View style={styles.arow}>
          <TouchableOpacity onPress={() => props.navigation.navigate('Login')}>
            <Image
              style={{height: 60, width: 60, resizeMode: 'contain'}}
              source={require('../../images/arr.jpeg')}
            />
          </TouchableOpacity>
        </View>
        <View style={styles.imgcon}>
          <View style={styles.Dp}>
            <View style={styles.dp}>
              <Image
                style={{height: 130, width: 130, resizeMode: 'contain'}}
                source={require('../../images/Dp.png')}
              />

              <View style={styles.cam}>
                <TouchableOpacity>
                  <Image
                    style={{
                      height: 40,
                      width: 40,
                      resizeMode: 'contain',
                      borderRadius: 48,
                    }}
                    source={require('../../images/camera.png')}
                  />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.spa}>
          <View style={styles.txt}>
            <Text style={{fontSize: 18, color: 'black', fontWeight: '500'}}>
              Full Name
            </Text>
          </View>
          <View style={styles.txtin}>
            <View style={styles.tt1}>
              <TextInput
                style={{fontSize: 18}}
                placeholder="Mohd Naeem"
                placeholderTextColor={'lightbrown'}
                keyboardType="default"
                maxLength={20}
                onChangeText={text => {
                  setName(text), nameValidate(text);
                }}
              />
            </View>
            {errorname !== null ? (
              <View
                style={{
                  height: height * 0.03,
                  width: '80%',
                }}>
                <Text style={{color: 'red', fontSize: 16}}>{errorname}</Text>
              </View>
            ) : null}
          </View>
        </View>

        <View style={styles.spa}>
          <View style={styles.txt}>
            <Text style={{fontSize: 18, color: 'black', fontWeight: '500'}}>
              Email
            </Text>
          </View>
          <View style={styles.txtin}>
            <View style={styles.tt1}>
              <TextInput
                style={{fontSize: 18,padding:5}}
                placeholder="re-mohd@indicchain.com"
                placeholderTextColor={'lightbrown'}
                keyboardType="default"
                onChangeText={text => {
                  setEmail(text), emailValidate(text);
                }}
              />
            </View>
            {errorEmail !== null ? (
              <View
                style={{
                  height: height * 0.03,
                  width: '80%',
                }}>
                <Text style={{color: 'red', fontSize: 16}}>{errorEmail}</Text>
              </View>
            ) : null}
          </View>
        </View>

        <View style={styles.spa}>
          <View style={styles.txxt}>
            <Text style={{fontSize: 18, color: 'black', fontWeight: '500'}}>
              Phone Number
            </Text>
          </View>
          <View style={styles.txtinp}>
            <View style={styles.img}>
              <View style={styles.flg}>
                <Image
                  style={{height: 40, width: 40, resizeMode: 'center'}}
                  source={require('../../images/flag.png')}
                />
              </View>
             <View style={styles.drm}>
             <View style={styles.drop}>
             <Dropdown label="+91" 
             data={data} />
           </View>
             </View>
            </View>
           <View style={{flexDirection:'column'}}>
           <View style={styles.tt11}>
           <TextInput
             style={{fontSize: 18}}
             placeholder="Mobile Number"
             placeholderTextColor={'lightbrown'}
             keyboardType='numeric'
             maxLength={10}
             onChangeText={text => {
               setPhone(text), phoneValidate(text);
             }}
           />
         </View>
         {errorPhone !== null ? (
           <View
             style={{
               height: height * 0.03,
              //  backgroundColor:'cyan',
               width: '80%',
             }}>
             <Text style={{color: 'red', fontSize: 16}}>{errorPhone}</Text>
           </View>
         ) : null}
           </View>
          </View>
        </View>
       <TouchableOpacity onPress={() => onSubmit()}>
       <View style={styles.btn}>
       <Text style={{fontSize:23,color:'white',fontWeight:'500'}}>Done</Text>
       </View>
       </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default Profile;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
  },
  arow: {
    height: height * 0.1,
    width: width * 0.95,
    alignSelf: 'center',
    justifyContent: 'center',
    // backgroundColor:'cyan',
  },
  imgcon: {
    height: height * 0.2,
    width: width * 0.8,
    justifyContent: 'center',
    alignSelf: 'center',
    // backgroundColor:'brown'
  },
  Dp: {
    height: height * 0.16,
    width: width * 0.5,
    alignSelf: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    // backgroundColor:'cyan'
  },
  dp: {
    height: height * 0.16,
    width: width * 0.35,
    alignSelf: 'center',
    justifyContent: 'flex-end',
    // backgroundColor:'cyan'
  },
  cam: {
    height: height * 0.06,
    width: width * 0.12,
    alignSelf: 'flex-end',
    position: 'absolute',
    borderRadius: 15,

    // backgroundColor:'green'
  },
  txt: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: 'center',
    // backgroundColor:'cyan'
  },
  txxt:{
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: 'center',
    // backgroundColor:'cyan'
  },
  txtin: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: 'center',
    justifyContent: 'center',
    // backgroundColor:'cyan'
  },
  tt1: {
    height: height * 0.05,
    width: width * 0.9,
    shadowColor:'#000000',
    shadowOpacity:1,
    shadowRadius:2.5,
    backgroundColor:'#fff',
    justifyContent: 'center',
    padding: 5,
    // borderRadius: 9,
    // borderColor:'lightbrown'
    // backgroundColor:'lightgrey'
  },
  txtinp: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    shadowColor:'#000000',
    shadowOpacity:1,
    shadowRadius:2.5,
    backgroundColor:'#fff',
    // backgroundColor: 'cyan',
  },
  img: {
    height: height * 0.05,
    width: width * 0.25,
    alignSelf: 'center',
    justifyContent: 'flex-start',
    flexDirection: 'row',
    // backgroundColor: 'green',
  },
  flg: {
    height: height * 0.05,
    width: width * 0.1,
    alignSelf: 'center',
    justifyContent: 'center',
    // backgroundColor: 'cyan',
  },
  drop: {
    height: height * 0.05,
    width: width * 0.14,
    alignSelf: 'center',
    justifyContent: 'flex-end',
    // alignItems:'flex-start'
    // backgroundColor: 'blue',
  },
  drm: {
    height: height * 0.05,
    width: width * 0.14,
    borderRightWidth:0.5,
    alignSelf: 'center',
    justifyContent: 'flex-end',
  },
  tt11: {
    height: height * 0.04,
    width: width * 0.65,
    // shadowColor:'#000000',
    // shadowOpacity:1,
    // shadowRadius:2.5,
    // backgroundColor:'#fff',
    justifyContent: 'flex-end',
    alignSelf: 'flex-end',
    padding: 5,
    // borderRadius: 9,
    // backgroundColor:'lightgrey'
  },
  spa: {
    height: height * 0.15,
    width: width * 0.9,
    alignSelf: 'center',
    // backgroundColor:'cyan'
  },
  btn:{
    height:height*0.06,
    width:width*0.9,
    // borderRadius:15,
    shadowColor:'#000000',
    shadowOpacity:1,
    shadowRadius:2.5,
    backgroundColor:'cyan',
    alignSelf:'center',
    alignItems:'center',
    justifyContent:'center',
    // backgroundColor:'cyan'
  }
});
