import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Dimensions,
  FlatList,
  Image,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import axios from 'axios';
// import AsyncStorage from '@react-native-async-storage/async-storage';
const {height, width} = Dimensions.get('window');

const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
];

const Home = props => {
  const [cardData, setCardData] = useState([]);
  console.log('===Card API===', cardData);

  useEffect(() => {
    GetListApi();
  }, [props.route]);

  const GetListApi = () => {
    axios({
      method: 'get',
      url: `https://fakestoreapi.com/products?limit=56`,
    })
      .then(async response => {
        if (response.status === 200) {
          console.log('====== home api response ======', response);
          setCardData(response?.data);
        } else {
          alert('Something went wrong.');
        }
      })
      .catch(err => {
        console.log('==== Login Catch error=====', err);
      });
  };

  const renderItem = ({item}) => {
    return (
      <View style={styles.Shadocontaner}>
        <View style={styles.ttl}>
          <Text numberOfLines={1} style={{color:'#000000',fontWeight:'600'}}>{item.title}</Text>
        </View>
        <View style={styles.flx}>
          <View style={styles.title}>
          <View style={styles.price}>
          <Text style={{color:'brown'}}>{item.price}</Text>
          </View>
          <View style={styles.ctg}>
          <Text style={{color:'#000000',fontWeight:'500'}}>{item.category}</Text>
          </View>
          </View>
          
          <View style={styles.imeg}>
            <Image
              source={{uri: item.image}}
              style={{height: 60, width: 60, resizeMode: 'contain'}}
            />
          </View>
          
        </View>
        <View style={styles.desc}>
                      <Text numberOfLines={2} style={{color:'grey'}}>{item.description}</Text>
          </View>
      </View>
    );
  };

  return (
    <SafeAreaView>
      <View style={styles.maincontainer}>
        {/* <View style={styles.Shadocontaner}></View> */}
        <FlatList data={cardData} renderItem={renderItem} />
      </View>
    </SafeAreaView>
  );
};

export default Home;

const styles = StyleSheet.create({
  maincontainer: {
    height: height * 1,
    width: width * 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  Shadocontaner: {
    height: height * 0.2,
    width: width * 0.9,
    shadowColor: '#fff',
    shadowOffset: {
      width: 1,
      height: 1,
      // backgroundColor:'cyan'
    },
    shadowRadius: 5,
    shadowOpacity: 0.5,
    backgroundColor: '#fff',
    marginVertical: 5,
    borderRadius: 5,
    // flexDirection:'row'
  },
  title: {
    height: height * 0.1,
    width: width * 0.6,
    // backgroundColor:'cyan'
  },
  imeg: {
    height: height * 0.1,
    width: width * 0.4,
    // backgroundColor:'cyan'
  },
  ttl: {
    height: height * 0.04,
    width: width * 1,
    justifyContent:'center',
    // backgroundColor:'red'
  },
  flx: {
    flexDirection: 'row',
  },
  price: {
    height:height*0.04,
    width:width*0.4
  },
  ctg: {
    height:height*0.04,
    width:width*0.4
  },
  desc: {
    height:height*0.05,
    width:width*1,
    // backgroundColor:'cyan'
  }
});
