import {
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  Image,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';

const {height, width} = Dimensions.get('window');
const Splash = props => {
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    setTimeout(function () {
      props.navigation.navigate('Onboarding');
      setIsVisible(true);
    }, 3000);
  }, []);

  return (
    <View style={styles.main}>
      <View style={styles.Image}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate('Onboarding')}>
          <Image
            style={{height: 250, width: 250, resizeMode: 'contain'}}
            source={require('../../images/Splash.jpeg')}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Splash;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
    // backgroundColor: 'cyan'
  },
  Image: {
    height: height * 0.4,
    width: width * 0.65,
    // backgroundColor: 'pink',
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    // marginHorizontal: 10,
    marginVertical: 170,
  },
});
