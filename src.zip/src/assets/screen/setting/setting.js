import {
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Switch,
  Modal,
  Text,
  Image,
  View,
} from 'react-native';
import React, {useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
// import SwitchToggle from "react-native-switch-toggle";

const {height, width} = Dimensions.get('window');
const Setting = props => {
  const [modalVisibleLogout, setModalVisibleLogout] = useState(false);

  const [isOnEnabled, setIsOnEnabled] = useState(false);
  const toggleOnSwitch = () => setIsOnEnabled(previousState => !previousState);

  const [isOffEnabled, setIsOffEnabled] = useState(false);
  const toggleOffSwitch = () =>
    setIsOffEnabled(previousState => !previousState);

  const [isOnnEnabled, setIsOnnEnabled] = useState(false);
  const toggleOnnSwitch = () =>
    setIsOnnEnabled(previousState => !previousState);

  const [isOnxEnabled, setIsOnxEnabled] = useState(false);
  const toggleOnxSwitch = () =>
    setIsOnxEnabled(previousState => !previousState);

  const [isEnabled, setIsEnabled] = useState(false);
  const toggleSwitch = () => setIsEnabled(previousState => !previousState);
  const Logout = async () => {
    console.log("====== Expired token ======", value);
    const value = await AsyncStorage.removeItem("token");
  }

  return (
    <View style={styles.main}>
      <View style={styles.uper}></View>
      <View style={styles.lower}>
        <View style={styles.semain}>
          <View style={styles.txt}>
            <Text style={{fontSize: 33}}>Setting</Text>
          </View>
          <View style={styles.img}>
            <TouchableOpacity  onPress={() => setModalVisibleLogout(!modalVisibleLogout)}>
              <Text style={{fontSize: 33,color:'red'}}>Logout</Text>
            </TouchableOpacity>
            </View>


          <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisibleLogout}
          onRequestClose={() => {
            setModalVisibleLogout(!modalVisibleLogout);
          }}>
          <View style={styles.LogoutmainContainer}>
            <View style={styles.LogoutModalSubContainer}>
              <View style={styles.LogoutHeadingContainer}>
                <View style={{height: height * 0.07, justifyContent: 'center'}}>
                  <Text
                    style={[styles.LogoutHeadingTxtContainer, {fontSize: 20}]}>
                    Logout
                  </Text>
                </View>
                <View style={{height: height * 0.08, justifyContent: 'center'}}>
                  <Text style={[styles.LogoutHeadingTxtContainer]}>
                    Are you sure, you want to Logout ?
                  </Text>
                </View>
  
                <View style={styles.LogoutButtonMainContainer}>
                  <View style={styles.LogoutbtnContainer}>
                    <TouchableOpacity 
                      style={{
                        height: 45,
                        width: width * 0.25,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: 'orange',
                        borderRadius: 5,
                      }}
                      onPress={() => props.navigation.navigate('Login')}>
                      <Text style={{fontSize: 18, color: 'white'}}>Yes</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={styles.LogoutbtnContainer}>
                    <TouchableOpacity
                      style={{
                        height: 45,
                        width: width * 0.25,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: 'orange',
                        borderRadius: 5,
                      }}
                      onPress={() => setModalVisibleLogout(!modalVisibleLogout)}>
                      <Text style={{fontSize: 18, color: 'white'}}>No</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </Modal>
        


        </View>
        <View style={styles.images}>
          <View style={styles.cld}>
            <TouchableOpacity>
              <Image
                style={{height: 70, width: 70, resizeMode: 'contain'}}
                source={require('../../images/cloud.png')}
              />
            </TouchableOpacity>
            <Text style={{fontSize: 18}}>cloud</Text>
          </View>
          <View style={styles.bcp}>
            <TouchableOpacity>
              <Image
                style={{height: 70, width: 70, resizeMode: 'contain'}}
                source={require('../../images/backup.png')}
              />
            </TouchableOpacity>
            <Text style={{fontSize: 17}}>All Backups</Text>
          </View>
        </View>
        <View style={styles.tt2}>
          <Text style={{fontSize: 18}}>Application Backup</Text>
        </View>
        <View style={styles.music}>
          <View style={styles.con1}>
            <View style={styles.img1}>
              <Image
                style={{height: 40, width: 40}}
                source={require('../../images/music.png')}
              />
            </View>
            <View style={styles.tt3}>
              <Text style={{fontSize: 19}}>Music</Text>
            </View>
          </View>
          <View style={styles.switch}>
            <Switch
              trackColor={{false: '#767577', true: '#81b0ff'}}
              thumbColor={isOnEnabled ? '#f5dd4b' : '#f4f3f4'}
              ios_backgroundColor="#3e3e3e"
              onValueChange={toggleOnSwitch}
              value={isOnEnabled}
            />
          </View>
        </View>

        <View style={styles.music}>
          <View style={styles.con1}>
            <View style={styles.img1}>
              <Image
                style={{height: 40, width: 40, resizeMode: 'contain'}}
                source={require('../../images/map.png')}
              />
            </View>
            <View style={styles.tt3}>
              <Text style={{fontSize: 19}}>Map</Text>
            </View>
          </View>
          <View style={styles.switch}>
            <Switch
              trackColor={{false: '#767577', true: '#81b0ff'}}
              thumbColor={isOffEnabled ? '#f5dd4b' : '#f4f3f4'}
              ios_backgroundColor="#3e3e3e"
              onValueChange={toggleOffSwitch}
              value={isOffEnabled}
            />
          </View>
        </View>

        <View style={styles.music}>
          <View style={styles.con1}>
            <View style={styles.img1}>
              <Image
                style={{
                  height: 35,
                  width: 35,
                  borderRadius: 14,
                  resizeMode: 'cover',
                }}
                source={require('../../images/file.png')}
              />
            </View>
            <View style={styles.tt3}>
              <Text style={{fontSize: 19}}>Files</Text>
            </View>
          </View>
          <View style={styles.switch}>
            <Switch
              trackColor={{false: '#767577', true: '#81b0ff'}}
              thumbColor={isOnxEnabled ? '#f5dd4b' : '#f4f3f4'}
              ios_backgroundColor="#3e3e3e"
              onValueChange={toggleOnxSwitch}
              value={isOnxEnabled}
            />
          </View>
        </View>

        <View style={styles.music}>
          <View style={styles.con1}>
            <View style={styles.img1}>
              <Image
                style={{height: 40, width: 40, resizeMode: 'center'}}
                source={require('../../images/galary.png')}
              />
            </View>
            <View style={styles.tt3}>
              <Text style={{fontSize: 19}}>Galary</Text>
            </View>
          </View>
          <View style={styles.switch}>
            <Switch
              trackColor={{false: '#767577', true: '#81b0ff'}}
              thumbColor={isOnnEnabled ? '#f5dd4b' : '#f4f3f4'}
              ios_backgroundColor="#3e3e3e"
              onValueChange={toggleOnnSwitch}
              value={isOnnEnabled}
            />
          </View>
        </View>

        <View style={styles.music}>
          <View style={styles.con1}>
            <View style={styles.img1}>
              <Image
                style={{height: 35, width: 35, resizeMode: 'contain'}}
                source={require('../../images/browser.png')}
              />
            </View>
            <View style={styles.tt3}>
              <Text style={{fontSize: 19}}>Browser</Text>
            </View>
          </View>
          <View style={styles.switch}>
            <Switch
              trackColor={{false: '#767577', true: '#81b0ff'}}
              thumbColor={isEnabled ? '#f5dd4b' : '#f4f3f4'}
              ios_backgroundColor="#3e3e3e"
              onValueChange={toggleSwitch}
              value={isEnabled}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default Setting;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
    backgroundColor: 'cyan',
  },
  uper: {
    height: height * 0.14,
    width: width * 1,
    backgroundColor: 'cyan',
  },
  lower: {
    height: height * 0.8,
    width: width * 1,
    backgroundColor: 'white',
    borderTopLeftRadius: 35,
    borderTopRightRadius: 35,
  },
  semain: {
    height: height * 0.14,
    width: width * 0.98,
    alignSelf: 'center',
    alignItems: 'center',
    // backgroundColor:'green',
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  txt: {
    height: height * 0.09,
    width: width * 0.44,
    alignItems: 'flex-start',
    // backgroundColor:'cyan'
  },
  img: {
    height: height * 0.09,
    width: width * 0.28,
    alignItems: 'flex-start',
    // backgroundColor:'cyan',
    
  },
  images: {
    height: height * 0.12,
    width: width * 0.7,
    alignSelf: 'center',
    flexDirection: 'row',
  },
  cld: {
    height: height * 0.08,
    width: width * 0.35,
    alignItems: 'center',
  },
  bcp: {
    height: height * 0.08,
    width: width * 0.35,
    alignItems: 'center',
  },
  tt2: {
    height: height * 0.09,
    width: width * 0.8,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  music: {
    height: height * 0.07,
    width: width * 0.95,
    flexDirection: 'row',
    alignSelf: 'center',
  },
  con1: {
    height: height * 0.07,
    width: width * 0.65,
    flexDirection: 'row',
  },
  img1: {
    height: height * 0.07,
    width: width * 0.17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tt3: {
    height: height * 0.07,
    width: width * 0.3,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  switch: {
    height: height * 0.07,
    width: width * 0.3,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  LogoutmainContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.4)',
      },
      LogoutModalMainContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        height: height * 1,
        backgroundColor: 'rgba(0, 0, 0, 0.67)',
      },
      LogoutModalSubContainer: {
        height: height * 0.2,
        width: width * 0.9,
        justifyContent: 'center',
        alignItems: 'center',
      },
      LogoutHeadingContainer: {
        height: height * 0.28,
        width: width * 0.9,
        backgroundColor: 'brown',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 15,
      },
      LogoutHeadingTxtContainer: {
        color: 'white',
        fontSize: 16,
        // marginTop: height * 0.03,
      },
      LogoutButtonMainContainer: {
        height: height * 0.09,
        width: width * 0.88,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
      },
      LogoutbtnContainer: {
        height: height * 0.1,
        alignItems: 'center',
        justifyContent: 'center',
        width: width * 0.45,
      },
      LogoutbuttonPressableView: {
        height: height * 0.055,
        width: width * 0.31,
        borderColor: '#000',
        borderRadius: height * 0.05,
        alignSelf: 'center',
        justifyContent: 'center',
        // backgroundColor: 'pink',
      },
      LogoutConfirmTxt: {
        color: '#fff',
        textAlign: 'center',
        fontSize: 18,
      },
      Setting:{
        marginTop:30,
        height:height*0.09,
        width:width*0.9,
        borderWidth:1,
        borderRadius:10 ,
        //justifyContent:'center',
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:'center'
      },
      settingone:{ 
        height:height* 0.09,
        width:width*0.2,
        justifyContent:'center',
        alignItems:'center',
        //backgroundColor:'yellow'
    
      },
});



// *************  Modal *************

// import {
//   StyleSheet,
//   Text,
//   View,
//   Modal,
//   Pressable,
//   Alert,
//   Dimensions,
//   Image,
// } from 'react-native';
// import React, {useState} from 'react';
// import {SafeAreaView} from 'react-native-safe-area-context';
// import {TouchableOpacity} from 'react-native-gesture-handler';
// import { NavigationContainer } from '@react-navigation/native';
// const {height, width} = Dimensions.get('window');

// const Setting = (props) => {
//   const [modalVisibleLogout, setModalVisibleLogout] = useState(false);
//   return (
//     <SafeAreaView>
//       <View
//         style={styles.maincontaner}>
//           <TouchableOpacity onPress={() => setModalVisibleLogout(!modalVisibleLogout)}>
//         <View style={styles.Setting}>
//           <View style={styles.settingone}>
//           <Text onPress={() => setModalVisibleLogout(!modalVisibleLogout)}   
//           style={{fontSize:18,fontWeight:'bold'}}
//           >
//             Logout
//           </Text>
//           </View>
//           <View style={styles.Imagearro}>
            
//           <Image
//           source={require('../../images/arr.jpeg')}
//           style={{height:40,width:40,}}
//           />
          
//           </View>
//         </View>
//         </TouchableOpacity>
//       </View>

//       {/* {/ *********** Logout Confirmation Modal *********** /} */}
//       <Modal
//         animationType="slide"
//         transparent={true}
//         visible={modalVisibleLogout}
//         onRequestClose={() => {
//           setModalVisibleLogout(!modalVisibleLogout);
//         }}>
//         <View style={styles.LogoutmainContainer}>
//           <View style={styles.LogoutModalSubContainer}>
//             <View style={styles.LogoutHeadingContainer}>
//               <View style={{height: height * 0.07, justifyContent: 'center'}}>
//                 <Text
//                   style={[styles.LogoutHeadingTxtContainer, {fontSize: 18}]}>
//                   Logout
//                 </Text>
//               </View>
//               <View style={{height: height * 0.08, justifyContent: 'center'}}>
//                 <Text style={[styles.LogoutHeadingTxtContainer]}>
//                   Are you sure, you want to Logout ?
//                 </Text>
//               </View>

//               <View style={styles.LogoutButtonMainContainer}>
//                 <View style={styles.LogoutbtnContainer}>
//                   <TouchableOpacity 
//                     style={{
//                       height: 45,
//                       width: width * 0.25,
//                       justifyContent: 'center',
//                       alignItems: 'center',
//                       backgroundColor: 'red',
//                       borderRadius: 5,
//                     }}
//                     onPress={() => props.navigation.navigate('Login')}>
//                     <Text style={{fontSize: 18, color: 'white'}}>Yes</Text>
//                   </TouchableOpacity>
//                 </View>
//                 <View style={styles.LogoutbtnContainer}>
//                   <TouchableOpacity
//                     style={{
//                       height: 45,
//                       width: width * 0.25,
//                       justifyContent: 'center',
//                       alignItems: 'center',
//                       backgroundColor: 'red',
//                       borderRadius: 5,
//                     }}
//                     onPress={() => setModalVisibleLogout(!modalVisibleLogout)}>
//                     <Text style={{fontSize: 18, color: 'white'}}>No</Text>
//                   </TouchableOpacity>
//                 </View>
//               </View>
//             </View>
//           </View>
//         </View>
//       </Modal>
//     </SafeAreaView>
//   );
// };

// export default Setting;

// const styles = StyleSheet.create({
//   maincontaner:{
//     height: height * 1,
//     width: width * 1,
//     //justifyContent:'center',
//     alignItems: 'center',
//    // backgroundColor: 'green',
//   },
//   // ********* Logout Modal Styling *********
//   LogoutmainContainer: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     backgroundColor: 'rgba(0,0,0,0.4)',
//   },
//   LogoutModalMainContainer: {
//     justifyContent: 'center',
//     alignItems: 'center',
//     height: height * 1,
//     backgroundColor: 'rgba(0, 0, 0, 0.67)',
//   },
//   LogoutModalSubContainer: {
//     height: height * 0.2,
//     width: width * 0.9,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   LogoutHeadingContainer: {
//     height: height * 0.28,
//     width: width * 0.9,
//     backgroundColor: 'orange',
//     justifyContent: 'center',
//     alignItems: 'center',
//     borderRadius: 15,
//   },
//   LogoutHeadingTxtContainer: {
//     color: 'white',
//     fontSize: 14,
//     // marginTop: height * 0.03,
//   },
//   LogoutButtonMainContainer: {
//     height: height * 0.09,
//     width: width * 0.88,
//     justifyContent: 'center',
//     alignItems: 'center',
//     flexDirection: 'row',
//   },
//   LogoutbtnContainer: {
//     height: height * 0.1,
//     alignItems: 'center',
//     justifyContent: 'center',
//     width: width * 0.45,
//   },
//   LogoutbuttonPressableView: {
//     height: height * 0.055,
//     width: width * 0.31,
//     borderColor: '#000',
//     borderRadius: height * 0.05,
//     alignSelf: 'center',
//     justifyContent: 'center',
//     backgroundColor: 'red',
//   },
//   LogoutConfirmTxt: {
//     color: '#fff',
//     textAlign: 'center',
//     fontSize: 18,
//   },
//   Setting:{
//     marginTop:30,
//     height:height*0.09,
//     width:width*0.9,
//     borderWidth:1,
//     borderRadius:10 ,
//     //justifyContent:'center',
//     flexDirection:'row',
//     justifyContent:'space-between',
//     alignItems:'center'
//   },
//   settingone:{ 
//     height:height* 0.09,
//     width:width*0.2,
//     justifyContent:'center',
//     alignItems:'center',
//     //backgroundColor:'yellow'

//   },
//   Imagearro:{
//      height:height*0.09,
//      width:width*0.2,
//      justifyContent:'center',
//      alignItems:'center',
//      //backgroundColor:'yellow'
//   }

// });