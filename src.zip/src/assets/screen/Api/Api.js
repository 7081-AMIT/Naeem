import {StyleSheet,TouchableOpacity, SafeAreaView, Dimensions,Image, Text, View} from 'react-native';
import React, {useState, useEffect} from 'react';
import axios from 'axios';
// import AsyncStorage from '@react-native-async-storage/async-storage';

const {height, width} = Dimensions.get('window');
const DATA = [
  {
    copyright: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
  },
  {
    copyright: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    copyright: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
];
const Api = props => {
  const [cardData, setCardData] = useState([]);
  console.log('===Card API===', cardData);

  useEffect(() => {
    GetListApi();
  }, [props.route]);

  const GetListApi = () => {
    axios({
      method: 'get',
      url: `https://api.nasa.gov/planetary/apod?api_key=jDZZ6poH1R6bIavRYOLomvkrJAoiDuAfbvWWo9jL`,
    })
      .then(async response => {
        if (response.status === 200) {
          console.log('====== api response ======', response);
          setCardData(response?.data);
        } else {
          alert('Something went wrong.');
        }
      })
      .catch(err => {
        console.log('==== Login Catch error=====', err);
      });
  };

  return (
    <View style={styles.main}>
      <SafeAreaView>
        <View style={styles.text}>
          <Text> {cardData.copyright}</Text>
        </View>
        <View style={styles.txt}>
          <Text> {cardData.date}</Text>
        </View>
        <View style={styles.tte}>
          <Text>{cardData.explanation}</Text>
        </View>
        <View style={styles.text}>
        <Text>{cardData.media_type}</Text>
      </View>
        <View style={styles.trr}>
        <Image 
        style={{height:200,width:200,resizeMode:'contain'}}
        source={{uri: cardData.hdurl}}
              />
        </View>
       
        <View style={styles.text}>
          <Text>{cardData.service_version}</Text>
        </View>
        <View style={styles.text}>
        <Text>{cardData.title}</Text>
      </View>
      <View style={styles.text}>
      <Text>{cardData.url}</Text>
    </View>
    <View style={{height:height*0.07,justifyContent:'center',alignItems:'center',}}>
    <TouchableOpacity onPress={() =>props.navigation.navigate('Home')}>
    <Text>Next</Text>
    </TouchableOpacity>
    </View>
      </SafeAreaView>
    </View>
  );
};

export default Api;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
    // justifyContent:'space-evenly'
    // backgroundColor:'cyan'
  },
  text: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: 'center',
    justifyContent: 'center',

    // backgroundColor:'green'
  },
  txt: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: 'center',
    justifyContent: 'center',

    // backgroundColor:'green'
  },
  tte: {
    height: height * 0.35,
    width: width * 0.9,
    alignSelf: 'center',
    justifyContent: 'center',

    // backgroundColor:'green'
  },
  trr: {
    height: height * 0.15,
    width: width * 0.9,
    alignSelf: 'center',
    justifyContent: 'center',

    // backgroundColor:'green'
  },
});
