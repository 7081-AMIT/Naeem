import  React,{useState,useEffect} from 'react';
import {View, Text} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Setting from '../assets/screen/setting/setting';
import Home from '../assets/screen/Home/home';
import MainTab from '../navigation/tabnavigator';
import Splash from '../assets/screen/Splash/Splash';
import Onboarding from '../assets/screen/Onboarding/Onboarding';
import Profile from '../assets/screen/Profile/Profile';
import Signup from '../assets/screen/Signup/Signup';
import Login from '../assets/screen/Login/Login';
import Api from '../assets/screen/Api/Api';


const Stack = createNativeStackNavigator();

function Routes() {
  const [Token, setToken] = useState('');

  useEffect(async () => {
    const value = await AsyncStorage.getItem('token');

    setToken(value);
  }, []);
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        {Token ? (
          <>
            <Stack.Screen name="Tabnavigator" component={MainTab} />
            <Stack.Screen name="Login" component={Login} />
          </>
        ) : (
          <>
            <Stack.Screen name="Splash" component={Splash} />
            <Stack.Screen name="Onboarding" component={Onboarding} />
            <Stack.Screen name="Login" component={Login} />
            <Stack.Screen name="Signup" component={Signup} />
            <Stack.Screen name="Home" component={Home} />
            <Stack.Screen name="Tabnavigator" component={MainTab} />
            <Stack.Screen name="Api" component={Api} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default Routes;