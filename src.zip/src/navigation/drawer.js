import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {createDrawerNavigator} from '@react-navigation/drawer';
// import {NavigationContainer} from '@react-navigation/native';

import Home from '../assets/screen/Home/home';

import Setting from '../assets/screen/setting/setting';
import Signup from '../assets/screen/Signup/Signup';
import Profile from '../assets/screen/Profile/Profile';

const DrawerStack = createDrawerNavigator();

const Drawers = props => {
  return (
    <DrawerStack.Navigator screenOptions={{headerShown: true}}>
      <DrawerStack.Screen name="Home" component={Home} />
      <DrawerStack.Screen name="Profile" component={Profile} />
      <DrawerStack.Screen name="Setting" component={Setting} />
      <DrawerStack.Screen name="Signup" component={Signup} />
    </DrawerStack.Navigator>
  );
};

export default Drawers;

const styles = StyleSheet.create({});