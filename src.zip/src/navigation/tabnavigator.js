import {StyleSheet, Text, View, Image, Dimensions} from 'react-native';
import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
const {height, width} = Dimensions.get('window');

import Home from '../assets/screen/Home/home';

import Setting from "../assets/screen/setting/setting"
import Drawers from './drawer';
import Profile from '../assets/screen/Profile/Profile';



const Tab = createBottomTabNavigator();
const MainTab = () => {
  return (
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarShowLabel: false,
          position: 'absolute',
          tabBarStyle: {
            position: 'absolute',
            height: height / 10,
            backgroundColor: '#FFFFFF',
            width: width,
            alignItems: 'center',
            borderTopLeftRadius: height / 30,
            borderTopRightRadius: height / 30,
            borderColor: 'red',
            borderTopWidth: 0,
            bottom: -height * 0.0,
          },
        }}>
        <Tab.Screen
          name="Home"
          component={Drawers} // Drawer function call here
          options={{
            // tabBarLabel: "Fantasy cricket",
            tabBarIcon: ({focused, color, size}) =>
              focused ? (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/home.png')}
                    resizeMode="contain"
                    style={styles.img}
                  />
                  <Text
                    style={{
                      fontSize: height / 75,
                      color: 'rgba(251, 109, 58, 1)',
                    }}>
                    Home
                  </Text>
                </View>
              ) : (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/home1.png')}
                    resizeMode="contain"
                    style={styles.image}
                  />
                  <Text style={{fontSize: height / 75, color: 'Black'}}>
                    Home
                  </Text>
                </View>
              ),
          }}
        />
        <Tab.Screen
          name="Profile"
          component={Profile}
          options={{
            tabBarIcon: ({focused, color, size}) =>
              focused ? (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/admin.jpeg')}
                    resizeMode="contain"
                    style={styles.img}
                  />
                  <Text
                    style={{
                      fontSize: height / 75,
                      color: 'rgba(251, 109, 58, 1)',
                    }}>
                    Profile
                  </Text>
                </View>
              ) : (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/user2.png')}
                    resizeMode="contain"
                    style={styles.image}
                  />
                  <Text style={{fontSize: height / 75, color: 'black'}}>
                    Profile
                  </Text>
                </View>
              ),
          }}
        />

        <Tab.Screen
          name="Setting"
          component={Setting}
          options={{
            tabBarIcon: ({focused, color, size}) =>
              focused ? (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/setting.png')}
                    resizeMode="contain"
                    style={styles.img}
                  />
                  <Text
                    style={{
                      fontSize: height / 75,
                      color: 'rgba(251, 109, 58, 1)',
                    }}>
                    Setting
                  </Text>
                </View>
              ) : (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/setting1.png')}
                    resizeMode="contain"
                    style={styles.image}
                  />
                  <Text style={{fontSize: height / 75, color: 'black'}}>
                    Setting
                  </Text>
                </View>
              ),
          }}
        />

        {/*<Tab.Screen
          name="Signup"
          component={Signup}
          options={{
            tabBarIcon: ({focused, color, size}) =>
              focused ? (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/edit.png')}
                    resizeMode="contain"
                    style={styles.img}
                  />
                  <Text
                    style={{
                      fontSize: height / 75,
                      color: 'rgba(251, 109, 58, 1)',
                    }}>
                    Signup
                  </Text>
                </View>
              ) : (
                <View style={styles.TabImageContainer}>
                  <Image
                    source={require('../assets/images/editp.png')}
                    resizeMode="contain"
                    style={styles.image}
                  />
                  <Text style={{fontSize: height / 75, color: 'black'}}>
                    Signup
                  </Text>
                </View>
              ),
          }}
        /> */}

       
      </Tab.Navigator>
  );
};

export default MainTab;

const styles = StyleSheet.create({
  img: {
    height: height * 0.06,
    width: width * 0.06,
  },
  image: {
    height: height * 0.06,
    width: width * 0.06,
    resizeMode:"contain"
  },
  TabImageContainer: {
    height: height * 0.08,
    width: width * 0.2,
    justifyContent: 'center',
    alignItems: 'center',
  },
});