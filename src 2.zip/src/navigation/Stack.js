import React from "react";
import { View, Text } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Register from "../../src/screens/Auth/Register/Register";
import PhoneVerification from "../screens/Auth/PhoneVerification/PhoneVerification";
import PhoneVerificationOtp from "../screens/Auth/PhoneVerificationOtp/PhoneVerificationOtp";
import ForgotPasswordEmail from "../screens/Auth/ForgotPasswordEmail/ForgotPasswordEmail";
import ForgotPasswordPhone from "../screens/Auth/ForgotPasswordPhone/ForgotPasswordPhone";
import Bank from "../screens/Bank/Bank";
import AddBankAccount from "../screens/AddBankAccount/AddBankAccount";
import ForgotOtp from "../screens/Auth/ForgotOtp/ForgotOtp";
import ForgotNewPassword from "../screens/ForgotCreatNewPassword/ForgotCreatNewPassword";
import ForgotCreatNewPassword from "../screens/ForgotCreatNewPassword/ForgotCreatNewPassword";
import Login from '../../src/screens/Auth/Login_Mobile/Login';
import Splash from '../../src/screens/Auth/Splash/Splash';
import Phone from '../../src/screens/Phone_number/Phone';
import Create from '../../src/screens/Create_Account/Create';
import Account from '../../src/screens/Persnal_account/Account';
import Verify from '../../src/screens/Phone_Verification/Verify';
import Identity from '../../src/screens/Auth/Identity_Verification/Identity';
import Dlverify from '../../src/screens/Auth/Identity_Verify2/Dlverify';
import Driver from '../../src/screens/Auth/Driver_license/Driver';
import Email from '../../src/screens/Auth/Email_Verify/Email';
import Selfie from '../../src/screens/Auth/Selfie/Selfie';
import Document from '../../src/screens/Auth/Document_Upload/Document';
import Selfie2 from '../../src/screens/Auth/Take_Selfie/Selfie2';
import Home from "../screens/Auth/Home/Home";
const Stack = createNativeStackNavigator();
function Routes() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Splash" component={Splash} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Phone" component={Phone} />
        <Stack.Screen name="Create" component={Create} />
        <Stack.Screen name="Account" component={Account} />
        <Stack.Screen name="Verify" component={Verify} />
        <Stack.Screen name="Email" component={Email} />
        <Stack.Screen name="Identity" component={Identity} />
        <Stack.Screen name="Dlverify" component={Dlverify} />
        <Stack.Screen name="Driver" component={Driver} />
        <Stack.Screen name="Selfie" component={Selfie} />
        <Stack.Screen name="Document" component={Document} />
        <Stack.Screen name="Selfie2" component={Selfie2} />
        <Stack.Screen name="Register" component={Register} />
        
        <Stack.Screen name="PhoneVerification" component={PhoneVerification} />
        <Stack.Screen
          name="PhoneVerificationOtp"
          component={PhoneVerificationOtp}
        />
        <Stack.Screen name="Bank" component={Bank} />
        <Stack.Screen name="AddBankAccount" component={AddBankAccount} />
        <Stack.Screen
          name="ForgotPasswordEmail"
          component={ForgotPasswordEmail}
        />
        <Stack.Screen
          name="ForgotPasswordPhone"
          component={ForgotPasswordPhone}
        />

        <Stack.Screen name="ForgotOtp" component={ForgotOtp} />
        <Stack.Screen
          name="ForgotCreatNewPassword"
          component={ForgotCreatNewPassword}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
export default Routes;

// screenOptions={{headerShown: false}}
