import {
  StyleSheet,
  Text,
  SafeAreaView,
  Dimensions,
  TouchableOpacity,
  TextInput,
  Image,
  View,
} from "react-native";
import React,{useState} from "react";
import { IMAGEPATH } from "../../assets/icon";
import { COLORS } from "../../utils/Color";
import { Dropdown } from "react-native-material-dropdown";
const { height, width } = Dimensions.get("window");

const data = [
  {
    value: "+92",
  },
  {
    value: "+1",
  },
];
const Phone = (props) => {
    const [phone, setPhone] = useState('');
  const [errorPhone, setErrorPhone] = useState('');

  const phoneValidate = phone => {
    var Regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (phone === '' || phone === undefined || phone === null) {
      setErrorPhone('*please enter phone number');
    } else if (!Regex.test(phone)) {
      setErrorPhone('*please enter vaid number');
    } else {
      setErrorPhone(null);
    }
  };

  const validate = () => {
    var Rgx = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    const flag = true;
    if (phone === '') {
        setErrorPhone('*please enter phone number');
        return !flag;
      }
      if (phone === '' || phone === undefined || phone === null) {
        setErrorPhone('*Please enter phone number');
        return !flag;
      }
      if (!Rgx.test(phone)) {
        setErrorPhone('*Please enter valid Phone number');
        return !flag;
      } else {
      setErrorPhone(null);
    }
      return flag;
    };

    const onSubmit = () => {
        if (validate()) {
        //   alert('Sussessful')
          props.navigation.navigate('Create');
        } else {
          // alert('Something went wrong');
        }
      };

  return (
    <SafeAreaView>
      <View style={styles.main}>
        <View style={styles.bgcimg}>
          <View style={styles.backimg}>
           <TouchableOpacity onPress={() =>props.navigation.navigate('Email')}>
           <Image
           style={{ height: 50, width: 50, resizeMode: "contain" }}
           source={IMAGEPATH.AROW_IMAGE}
         />
           </TouchableOpacity>
          </View>
          <View style={styles.crossimg}>
           <TouchableOpacity onPress={() =>props.navigation.navigate('Phone')}>
           <Image
           style={{ height: 15, width: 15, resizeMode: "contain" }}
           source={IMAGEPATH.CROSS_IMAGE}
         />
           </TouchableOpacity>
          </View>
        </View>
        <View style={styles.textcon}>  
          <Text
            style={{
              fontSize: 30,
              fontWeight: "700",
              color: "#000000",
              fontFamily: "Lato-Regular",
            }}
          >
            Enter Phone Number
          </Text>
        </View>
        <View style={styles.txt}>
          <Text
            style={{
              fontSize: 16,
              fontWeight: "400",
              color: "#343434",
              fontFamily: "Lato-Regular",
            }}
          >
            Enter your phone number to be used for your account.
          </Text>
        </View>
        <View style={styles.textinputcon}>
          <View style={styles.txtcon}>
            <Text
              style={{
                fontFamily: "Lato-Regular",
                fontSize: 18,
                color: "#343434",
                fontWeight: "400",
              }}
            >
              Phone Number
            </Text>
          </View>
          <View style={styles.txtinpt}>
           <View style={styles.errorcon}>
           <View style={styles.inpt}>
           <View style={styles.imgcon}>
             <View style={styles.img}>
               <View style={styles.bimg}>
                 <Image
                   style={{ height: 25, width: 25, resizeMode: "contain" }}
                   source={IMAGEPATH.FLAG_IMAGE}
                 />
               </View>
             </View>
             <View style={styles.drop}>
               <Dropdown label="+91" data={data} />
             </View>
           </View>
           <View style={styles.txtphone}>
             <View style={styles.ttx1}>
               <TextInput
               style={{fontSize:14,color:'black'}}
                 placeholder="Enter your phone number"
                 placeholderTextColor={"#BCBCBC"}
                 keyboardType="numeric"
                 maxLength={10}
                 onChangeText={(text) => {
                   setPhone(text), phoneValidate(text);
                 }}
               />
             </View>
           </View>
         </View>
       {errorPhone !== null ? (
         <View
           style={{
             height: '30%',
             width: '97%',
             alignSelf:'center',
             // backgroundColor: 'green',
           }}>
           <Text style={{color: 'red', fontSize: 16}}>{errorPhone}</Text>
         </View>
       ) : null}
           </View>
           </View>

        </View>
        <View style={styles.btncon}>
         <TouchableOpacity onPress={() => props.navigation.navigate("Create")}>
         <View style={styles.btn}>
         <Text
           style={{
             
             fontSize:20,
             fontWeight:'700',
             color: COLORS.WHITE,
           }}
         >
           Next
         </Text>
       </View>
         </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Phone;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
  },
  bgcimg: {
    height: height * 0.1,
    width: width * 0.95,
    alignSelf: "center",
    alignItems:'center',
    flexDirection: "row",
    // backgroundColor:'cyan',
    justifyContent: "space-between",
  },
  backimg: {
    height: height * 0.05,
    justifyContent: "center",
    alignItems: "flex-start",
    width: width * 0.2,
    // backgroundColor: "cyan",
  },
  crossimg: {
    height: height * 0.05,
    width: width * 0.1,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },
  textcon: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "flex-end",
    //   backgroundColor:'cyan'
  },
  txt: {
    height: height * 0.07,
    width: width * 0.9,
    justifyContent: "center",
    alignSelf: "center",
    //   backgroundColor:'red'
  },
  textinputcon: {
    height: height * 0.3,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'green'
  },
  txtcon: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'red'
  },
  txtinpt: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    //   borderWidth:0.17,
    shadowColor: "rgba(0, 0, 0, 0.1)",
    //   shadowOpacity:1,
    borderRadius: 7,
    backgroundColor: "#FFFFFF",
  },
  errorcon:{
    height: height * 0.1,
    width: width * 0.9,
    // borderWidth: 0.3,
    // borderColor: "#BCBCBC",
    // backgroundColor:'cyan',
    alignSelf: "center",
    // flexDirection: "row",
  },
  inpt: {
    height: height * 0.06,
    width: width * 0.9,
    borderWidth: 0.3,
    borderColor: "#BCBCBC",
    // backgroundColor:'green',
    alignSelf: "center",
    flexDirection: "row",
  },
  imgcon: {
    height: height * 0.06,
    width: width * 0.22,
    flexDirection: "row",
    // backgroundColor:'cyan'
  },
  img: {
    height: height * 0.06,
    width: width * 0.1,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor:'yellow'
  },
  bimg: {
    height: height * 0.025,
    width: width * 0.37,
    alignItems: "center",
    borderRightWidth: 0.2,
    justifyContent: "center",
    // backgroundColor:'cyan'
  },
  drop: {
    height: height * 0.06,
    width: width * 0.14,
    justifyContent: "flex-end",
    // backgroundColor:'red'
  },
  txtphone: {
    height: height * 0.06,
    width: width * 0.81,
    justifyContent: "center",
    // backgroundColor:'red'
  },
  ttx1: {
    height: height * 0.06,
    width: width * 0.74,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'red'
  },
  btncon: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
  },
  btn: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 7,
    backgroundColor: "#2C723E",
  },
});
