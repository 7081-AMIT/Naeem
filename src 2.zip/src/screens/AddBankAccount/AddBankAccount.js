import {
  Dimensions,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Image,
  SafeAreaView,
  Modal,
} from "react-native";
import { Dropdown } from "react-native-material-dropdown";
import React, { useState, useEffect } from "react";
import { COLORS } from "../../utils/Color";
import { IMAGEPATH } from "../../assets/icon";
import { Colors } from "react-native/Libraries/NewAppScreen";
const { height, width } = Dimensions.get("window");

const AddBankAccount = (props) => {
  const [modalVisible, setModalVisible] = useState(false);

  return (
    <View style={styles.ImageBackgroundcontainer}>
      <View style={styles.HeaderButton}>
        <TouchableOpacity onPress={() => props.navigation.navigate("Register")}>
          <View style={styles.arrowV}>
            <Image source={IMAGEPATH.Back_ARROW_IMAGE} />
          </View>
        </TouchableOpacity>
        <View style={styles.tital}>
          <Text
            style={{
              fontSize: height / 38,
              fontWeight: "bold",
              color: COLORS.BLACK_TEXT_COLOR,
            }}
          >
            Settings
          </Text>
        </View>
      </View>

      <View style={styles.mainImgV}>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.BANK_USER_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.BANK_SETTING_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.USER_INFO_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setModalVisible(true)}>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.BANK_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.ADDUSER_IMAGE} />
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.topcontainer}>
        <TouchableOpacity>
          <Text
            style={{
              color: "black",
              fontSize: height / 50,
              //   fontWeight: "bold",
              //   fontFamily: "Lato",
            }}
          >
            Bank Name
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.AddBank}>
        <View style={styles.saveMoney}>
          <Image
            source={IMAGEPATH.SAVE_MONEY_IMAGE}
            style={{ height: 25, width: 25 }}
          />
          <Text>HDFC Bank</Text>
        </View>
        <View style={styles.cardDetails}>
          <View style={styles.txtDetails}>
            <Text
              style={{ color: COLORS.BORDER_WITH_COLOR, fontSize: width / 35 }}
            >
              Account Number
            </Text>
          </View>
          <View style={styles.txtDetails}>
            <Text
              style={{ color: COLORS.BORDER_WITH_COLOR, fontSize: width / 35 }}
            >
              Saving Account No xxxx6425
            </Text>
          </View>
          <View style={styles.txtDetails}>
            <Text
              style={{ color: COLORS.BORDER_WITH_COLOR, fontSize: width / 35 }}
            >
              Account Holder Name : Ajay
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};

export default AddBankAccount;

const styles = StyleSheet.create({
  ImageBackgroundcontainer: {
    height: height * 1,
    width: width * 1,
    alignItems: "center",
    // backgroundColor: "#E5E5E5",
    // backgroundColor:'skyblue'
  },
  HeaderButton: {
    flexDirection: "row",
    height: height * 0.07,
    width: width * 0.98,
    alignSelf: "center",
    // backgroundColor: "red",
  },

  topcontainer: {
    height: height * 0.06,
    width: width * 0.9,
    // backgroundColor: "pink",
    //justifyContent:'center',
    alignItems: "center",
    flexDirection: "row",
  },

  textcontainer: {
    height: height * 0.1,
    width: width * 0.7,
    //backgroundColor:'green',
    justifyContent: "center",
    alignItems: "center",
    // fontFamily: "Lato",
  },
  arrowV: {
    height: height * 0.07,
    width: width * 0.15,
    // backgroundColor: "green",
  },

  tital: {
    height: height * 0.07,
    width: width * 0.6,
    // backgroundColor: "yellow",
    fontFamily: "Lato",
    justifyContent: "center",
  },
  mainImgV: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "cyan",
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
  },
  Image: {
    height: height * 0.07,
    width: width * 0.15,
    // backgroundColor: "red",
    justifyContent: "center",
    alignItems: "center",
  },
  AddBank: {
    height: height * 0.15,
    width: width * 0.9,
    alignSelf: "center",
    // alignItems: "center",
    // borderWidth: 1,
    justifyContent: "space-evenly",
    flexDirection: "row",

    borderColor: "rgb( 204,198,204)",
    shadowColor: "#000000",
    shadowRadius: 5,
    shadowOffset: {
      height: 0.5,
      width: 0.5,
    },
    shadowOpacity: 0.3,
    backgroundColor: "#FFFFFF",
    // backgroundColor:'red'
    alignItems: "center",
  },
  saveMoney: {
    height: height * 0.08,
    width: width * 0.3,
    // backgroundColor: "red",
    // alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },
  cardDetails: {
    height: height * 0.09,
    width: width * 0.5,
    // backgroundColor: "green",
    justifyContent: "space-evenly",
  },
  txtDetails: {
    height: height * 0.03,
    width: width * 0.5,
  },

  Btn: {
    height: height * 0.09,
    width: width * 1,
    // borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  Confirm: {
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    height: height * 0.07,
    width: width * 0.9,
    borderRadius: 7,
    // borderWidth: 1,
    backgroundColor: COLORS.BUTTON_BACKGROUND_COLOR,
    // fontFamily: "Lato",
  },
});
