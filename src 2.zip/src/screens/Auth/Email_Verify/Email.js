import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  SafeAreaView,
  Image,
  TextInput,
  TouchableOpacity,
} from "react-native";
import react from "react";
import CountDown from "react-native-countdown-component";
import { IMAGEPATH } from "../../../assets/icon";
import { COLORS } from "../../../utils/Color";

// import PhoneVerification from "../PhoneVerification/PhoneVerification";
const { height, width } = Dimensions.get("window");

const Email = (props) => {
 

  return (
    <SafeAreaView>
      <View style={styles.MainConatiner}>
        <View style={styles.headerButton}>
          <View style={styles.bgcimg}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate("Register")}
            >
              <Image source={IMAGEPATH.AROW_IMAGE} />
            </TouchableOpacity>
          </View>
          <View style={styles.crs}>
          <TouchableOpacity
            // onPress={() => props.navigation.navigate("Home")}
          >
            <Image source={IMAGEPATH.CROSS_IMAGE} />
          </TouchableOpacity>
          </View>
        </View>
        <View style={styles.Tital}>
          <Text
            style={{
              fontSize: height / 40,
              fontWeight: "bold",
              color:'#343434'
            }}
          >
            Email Verification
          </Text>
        </View>
        <View style={styles.Tital2}>
          <View style={styles.txtNotes}>
            <Text style={{fontSize:height/60,color:'#343434',fontWeight:'400'}}>Please enter the 6-digit verification code that</Text>
          </View>
          <View style={styles.txtNotes}>
            <Text style={{fontSize:height/60,color:'#343434',fontWeight:'400'}}>was sent to umairsiddiqui@gmail.com The code is</Text>
          </View>
          <View style={styles.txtNotes}>
            <Text style={{fontSize:height/60,color:'#343434',fontWeight:'400'}}>valid for 30 minutes.</Text>
          </View>
        </View>
        <View style={styles.mail}>
          <Text
            style={{
             fontSize:height/60,
             color:'#343434',
              fontWeight:'400'
            }}
          >
            Phone Number Verification Code
          </Text>
        </View>
        <View style={styles.TxtInputMainV}>
          <View style={styles.TxtInput}>
            <TextInput 
            style={{color:'black'}}
            keyboardType="numeric" 
            maxLength={1} 
           
            />
          </View>
          <View style={styles.TxtInput}>
            <TextInput 
            style={{color:'black'}}
            keyboardType="numeric"
             maxLength={1} 
           
            />
          </View>
          <View style={styles.TxtInput}>
            <TextInput 
            style={{color:'black'}}
            keyboardType="numeric" 
            maxLength={1} 
            
            />
          </View>
          <View style={styles.TxtInput}>
            <TextInput 
            style={{color:'black'}}
            keyboardType="numeric" 
            maxLength={1} 
           
            />
          </View>
          <View style={styles.TxtInput}>
            <TextInput 
            style={{color:'black'}}
            keyboardType="numeric" 
            maxLength={1} 
           
            />
          </View>
          <View style={styles.TxtInput}>
            <TextInput 
            style={{color:'black'}}
            keyboardType="numeric" 
            maxLength={1} 
           
            />
          </View>
         
        </View>
        <View style={styles.verify}>
       
        </View>
        <View style={styles.Timer}>
          <View>
            <CountDown
              size={12}
              style={{color:'green'}}
              until={60*30}
              onFinish={() => alert("Time out")}
              digitStyle={
                {
                    // backgroundColor: "#000000",
                    // borderWidth: 2,
                    color:'green',
                    // borderColor: "#1CC625",
                  fontWeight:"bold",
                  // color:'black'
                }
              }
              digitTxtStyle={{ color: COLORS.BLACK_TEXT_COLOR }}
              timeLabelStyle={{ color: "red" }}
              separatorStyle={{ color: COLORS.BLACK_TEXT_COLOR }}
              timeToShow={["M", "S"]}
              timeLabels={{ m: null, s: null }}
              showSeparator
            />
          </View>
          <View>
            <TouchableOpacity>
              <Text
                style={{
                  color: "green",
                  textDecorationLine: "underline",
                }}
              >
                Resend Code
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.Button}>
          <TouchableOpacity onPress={() => props.navigation.navigate('Phone')}>
            <View style={styles.Touchable}>
              <Text style={{ color: "#FFFFFF", fontSize:18,fontWeight:'500' }}>Submit</Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Email;

const styles = StyleSheet.create({
  MainConatiner: {
    height: height * 1,
    width: width * 1,
  },
  headerButton: {
    height: height * 0.1,
    width: width * 0.95,
    // backgroundColor: "red",
    alignSelf: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  Tital: {
    height: height * 0.046,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "yellow",
    justifyContent: "center",
    fontFamily: "Lato",
  },
  Tital2: {
    height: height * 0.14,
    width: width * 1,
    alignSelf: "center",
    // backgroundColor: "red",
  },
  mail: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "green",
    justifyContent: "center",
    fontFamily: "Lato",
  },
  TxtInputMainV: {
    height: height * 0.07,
    width: width * 0.9,
    // backgroundColor: "cyan",
    justifyContent: "space-between",
    alignSelf: "center",
    flexDirection: "row",
  },
  TxtInput: {
    height: height * 0.07,
    width: width * 0.14,
    // borderWidth: 0.2,
    borderRadius: 7,
    // backgroundColor: "white",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",

    borderColor: "rgb( 204,198,204)",
    shadowColor: "#000000",
    shadowRadius: 5,
    // shadowOffset: {
    //   height: 0.5,
    //   width: 0.5,
    // },
    shadowOpacity: 0.1,
    backgroundColor: "#FFFFFF",
  },

  Button: {
    height: height * 0.17,
    width: width * 1,
    // backgroundColor: "blue",
    justifyContent: "flex-end",
  },
  Touchable: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2C723E",
    borderRadius: 7,
  },
  DropDown: {
    height: height * 0.06,
    width: width * 0.12,
    // backgroundColor: "red",
    justifyContent: "flex-end",
  },
  txtNotes: {
    height: height * 0.02,
    width: width * 0.9,
    alignSelf: "center",
    // borderWidth:1,
    height: height * 0.022,
    fontFamily: "Lato",
  },
  Timer: {
    height: height * 0.04,
    width: width * 0.9,
    // backgroundColor: "red",
    alignSelf: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  verify:{
    height:height*0.027,
    width:width*0.9,
    alignSelf:'center',
    // backgroundColor:"cyan"
  },
  crs:{
    height:height*0.06,
    width:width*0.2,
    justifyContent:'center',
    alignItems:'center',
    // backgroundColor:"cyan"
  }
});
