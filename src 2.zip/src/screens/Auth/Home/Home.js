// import {
//   StyleSheet,
//   Text,
//   View,
//   Dimensions,
//   TextInput,
//   Image,
//   TouchableOpacity,
//   ScrollView,
// } from "react-native";
// import React, { useState } from "react";
// import { Dropdown } from "react-native-material-dropdown";
// import { IMAGEPATH } from "../../../assets/icon";
// import { COLORS } from "../../../utils/Color";

// const { height, width } = Dimensions.get("window");
// const data = [
//   {
//     value: "MOHD",
//   },
//   {
//     value: "Loreum",
//   },
//   {
//     value: "Ipsum",
//   },
// ];

// const Home = () => {
//   const [change, setChange] = useState(null);

//   return (
//     <ScrollView>
//       <View style={styles.mainContainer}>
//         <View style={styles.fContainer}></View>
//         <View style={styles.ThirdView}>
//           <View style={styles.SecondContaiener}>
//             <View style={styles.humanLogoView}>
//               <View style={styles.humanmainView}>
//                 <View style={styles.humaninView}>
//                   <Image
//                     style={styles.ImageStyle}
//                     source={IMAGEPATH.HUMAN_IMAGE}
//                   />
//                 </View>
//                 <View>
//                   <View style={styles.HelloTextView}>
//                     <Text style={styles.hellotextStyle}>HELLO</Text>
//                   </View>
//                   <View style={styles.RelationInView}>
//                     <View style={styles.codeinView}>
//                       <Dropdown
//                         placeholder="Choose here"
//                         placeholderTextColor="#8B8B8B"
//                         data={data}
//                         disabledItemColor="#fff"
//                         style={{
//                           alignSelf: "flex-end",
//                           fontSize: 16,
//                           fontFamily: "lato-regular",
//                           color: " #000000",
//                         }}
//                         textColor="#343434"
//                         iconStyle={{ backgroundColor: "#8B8B8B" }}
//                         baseColor="#2C723E"
//                       />
//                     </View>
//                   </View>
//                 </View>
//               </View>
//             </View>
//             <View style={styles.bellIconView}>
//               <View style={styles.BellinView1}>
//                 <TouchableOpacity>
//                   <Image
//                     style={styles.ImageStyle1}
//                     source={IMAGEPATH.BELL_IMAGE}
//                   />
//                 </TouchableOpacity>
//               </View>
//               <View style={styles.BellinView1}>
//                 <TouchableOpacity>
//                   <Image
//                     style={styles.ImageStyle1}
//                     source={IMAGEPATH.HEADPHONE_IMAGE}
//                   />
//                 </TouchableOpacity>
//               </View>
//             </View>
//           </View>
//           <View style={styles.cardStyle}>
//             <View style={styles.cardStyleinView}>
//               <Image style={styles.Card_Image} source={IMAGEPATH.CARD_IMAGE} />
//             </View>
//             <View style={styles.soundView}>
//               <View style={styles.soundImageView}>
//                 <Image
//                   style={styles.soundImageStyle}
//                   source={IMAGEPATH.SOUND_IMAGE}
//                 />
//               </View>
//               <View style={styles.soundTextView}>
//                 <Text style={styles.soundTextStyle}>
//                   Announcement on the Suspennsion of the MANDOX
//                 </Text>
//               </View>
//             </View>
//           </View>

//           <View style={styles.arrowView}>
//             <TouchableOpacity>
//               <Image
//                 style={styles.lineImgeStyle}
//                 // source={ImagePath.Arrow_icon}
//               />
//             </TouchableOpacity>
//           </View>
//           <View style={styles.headingTextView}>
//             <Text style={styles.headingTextStyle}>
//               COMPLETE KYC TO DEPOSIT INR{" "}
//             </Text>
//           </View>
//         </View>
//         <View
//           style={{ height: height * 0.01, width: "100%", alignSelf: "center" }}
//         ></View>

//         <View style={styles.cryptoMainView}>
//           <View style={styles.iconView}>
//             <View style={styles.iconInnerView}>
//               <TouchableOpacity style={styles.iconInnerView}>
//                 <View>
//                   {/* <Image source={ImagePath.Swap_crypto} /> */}
//                 </View>
//                 <View>
//                   <TouchableOpacity>
//                     <Text style={styles.walletTextStyle}> Swap Crypto </Text>
//                   </TouchableOpacity>
//                 </View>
//               </TouchableOpacity>
//             </View>
//             <View style={styles.iconInnerView2}>
//               <TouchableOpacity style={styles.iconInnerView2}>
//                 <View>
//                   <Image source={IMAGEPATH.WALLET_IMAGE} />
//                 </View>
//                 <View>
//                   <TouchableOpacity>
//                     <Text style={styles.walletTextStyle}> Wallet </Text>
//                   </TouchableOpacity>
//                 </View>
//               </TouchableOpacity>
//             </View>
//           </View>
//           <View style={styles.iconView}>
//             <View style={styles.iconInnerView2}>
//               <TouchableOpacity style={styles.iconInnerView2}>
//                 {/* <Image source={ImagePath.Fixed_Deposite} /> */}
//                 <Text style={styles.walletTextStyle}> Fixed Deposite </Text>
//               </TouchableOpacity>
//             </View>
//             <View style={styles.iconInnerView2}>
//               <TouchableOpacity style={styles.iconInnerView2}>
//                 <View>
//                   <Image source={IMAGEPATH.TIMER_IMAGE} />
//                 </View>
//                 <View>
//                   <TouchableOpacity>
//                     <Text style={styles.walletTextStyle}> History </Text>
//                   </TouchableOpacity>
//                 </View>
//               </TouchableOpacity>
//             </View>
//           </View>
//         </View>
//         <View
//           style={{ height: height * 0.02, width: "100%", alignSelf: "center" }}
//         ></View>
//         <View style={styles.lastmainView}>
//           <View style={styles.inviteTextView}>
//             <View
//               style={{
//                 height: height * 0.04,
//                 width: width * 0.87,
//                 alignSelf: "center",
//                 justifyContent: "center",
//                 // backgroundColor:'blue'
//               }}
//             >
//               <Text style={styles.inviteTextStyle}>Invite Friends & </Text>
//             </View>
//           </View>
//           <View style={styles.earningVIew}>
//             <View
//               style={{
//                 height: height * 0.04,
//                 width: width * 0.87,
//                 alignSelf: "center",
//                 // justifyContent:'center'
//                 // backgroundColor:'blue'
//               }}
//             >
//               <Text style={styles.earningText}>Start Earning</Text>
//             </View>
//           </View>
//           <View style={styles.paraTextView}>
//             <View
//               style={{
//                 height: height * 0.04,
//                 width: width * 0.87,
//                 alignSelf: "center",
//                 // justifyContent:'center'
//                 // backgroundColor:'blue'
//               }}
//             >
//               <Text style={styles.paraTextStyle}>
//                 Whenever your friend makes an action on the platform you will
//                 receive a commission
//               </Text>
//             </View>
//           </View>
//           <View style={styles.TextView}>
//             <View
//               style={{
//                 height: height * 0.15,
//                 width: width * 0.54,
//                 alignSelf: "center",
//                 justifyContent: "center",
//                 //backgroundColor:'red'
//               }}
//             >
//               <View style={styles.TextInnerView}>
//                 <View style={styles.Text40View}>
//                   <Text style={styles.textstyle}>40%</Text>
//                 </View>
//                 <View style={styles.texesView}>
//                   <Text style={styles.textstyle1}>
//                     of the fees on their trades
//                   </Text>
//                 </View>
//               </View>
//               <View style={styles.TextInnerView}>
//                 <View style={styles.Text40View}>
//                   <Text style={styles.textstyle}>5%</Text>
//                 </View>
//                 <View style={styles.texesView}>
//                   <Text style={styles.textstyle1}>
//                     of the interest paid out on their assets
//                   </Text>
//                 </View>
//               </View>
//               <View style={styles.TextInnerView}>
//                 <View style={styles.Text40View}>
//                   <Text style={styles.textstyle}>5%</Text>
//                 </View>
//                 <View style={styles.texesView}>
//                   <Text style={styles.textstyle1}>
//                     of the interest accrued on their loans
//                   </Text>
//                 </View>
//               </View>
//             </View>
//             <View style={styles.Earn_Image}>
//               <Image
//                 style={styles.Earn_ImageStyle}
//                 // source={ImagePath.Earn_Icon}
//               />
//             </View>
//           </View>
//           <View style={styles.linkView}>
//             <View
//               style={{
//                 flexDirection: "column",
//                 justifyContent: "space-evenly",
//               }}
//             >
//               <View style={styles.linkInnerView}>
//                 <View style={styles.Text40View}>
//                   <Text style={styles.LinkText1}>Link:</Text>
//                 </View>
//                 <View style={styles.texesView1}>
//                   <Text style={styles.LinkText2}>
//                     https://abcd.com/register/erew7y
//                   </Text>
//                 </View>
//                 <View style={styles.linkInnerView1}>
//                   <TouchableOpacity style={styles.copyTouchable}>
//                     <Image source={IMAGEPATH.COPY_IMAGE} />
//                   </TouchableOpacity>
//                 </View>
//               </View>
//               <View
//                 style={{
//                   height: height * 0.01,
//                   width: width * 0.85,
//                   backgroundColor: "grey",
//                 }}
//               ></View>
//               <View style={styles.linkInnerView}>
//                 <View style={styles.Text40View}>
//                   <Text style={styles.LinkText1}>Code:</Text>
//                 </View>
//                 <View style={styles.texesView1}>
//                   <Text style={styles.LinkText2}>erew7y</Text>
//                 </View>
//                 <View style={styles.linkInnerView1}>
//                   <TouchableOpacity style={styles.copyTouchable}>
//                     <Image source={IMAGEPATH.COPY_IMAGE} />
//                   </TouchableOpacity>
//                 </View>
//               </View>
//             </View>
//           </View>
//           <View style={styles.TouchableView}>
//             <TouchableOpacity style={styles.TouchableOpacityStyle}>
//               <Image source={IMAGEPATH.SHARE_IMAGE} />
//               <Text style={styles.TouchableText}> Share</Text>
//             </TouchableOpacity>
//           </View>
//           <View style={styles.referalView}>
//             <TouchableOpacity>
//               <Text style={styles.lastText}>VISIT REFERRAL PAGE </Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </View>
//     </ScrollView>
//   );
// };

// export default Home;

// const styles = StyleSheet.create({
//   mainContainer: {
//     height: "100%",
//     width: "100%",
//     backgroundColor: "#E5E5E5",
//     // backgroundColor: '',
//     //justifyContent:'center'
//   },
//   fContainer: {
//     height: height * 0.06,
//     width: width * 0.1,
//   },
//   ThirdView: {
//     height: height * 0.48,
//     width: width * 0.99,
//     alignSelf: "center",
//     backgroundColor: "#E5E5E5",

//     alignSelf: "center",
//     shadowColor: "rgb(0,2,1)",
//     shadowOpacity: 0.1,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//     borderBottomLeftRadius: 20,
//     borderBottomRightRadius: 20,
//     justifyContent: "center",
//     // position: 'relative'
//   },
//   SecondContaiener: {
//     height: height * 0.07,
//     width: width * 0.95,
//     // backgroundColor: 'red',
//     alignSelf: "center",
//     justifyContent: "space-between",
//     flexDirection: "row",
//   },
//   humanLogoView: {
//     height: height * 0.08,
//     width: width * 0.25,
//     justifyContent: "center",
//     //backgroundColor:'red'
//   },
//   humanmainView: {
//     // borderWidth: 1,
//     //  borderRadius:95,
//     height: height * 0.07,
//     width: width * 0.38,
//     //justifyContent: 'center',
//     flexDirection: "row",
//     shadowColor: "rgb(0,0,0)",
//     shadowOpacity: 0,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//   },
//   BellinView1: {
//     // borderWidth: 1,
//     //  borderRadius:95,
//     height: height * 0.06,
//     width: width * 0.14,
//     justifyContent: "center",
//     alignSelf: "flex-end",
//   },
//   humaninView: {
//     //  borderWidth: 1,
//     //  borderRadius:95,
//     height: height * 0.07,
//     width: width * 0.14,
//     justifyContent: "center",
//   },
//   ImageStyle: {
//     height: height * 0.05,
//     width: width * 0.13,
//     resizeMode: "contain",
//     position: "absolute",
//     // alignSelf: 'center'
//   },
//   ImageStyle1: {
//     height: height * 0.02,
//     width: width * 0.09,
//     resizeMode: "contain",
//     position: "absolute",
//     // alignSelf: 'flex-end'
//   },
//   HelloTextView: {
//     height: height * 0.04,
//     width: width * 0.12,
//     // borderWidth: 1,
//     justifyContent: "center",
//     // alignItems: 'center'
//   },
//   hellotextStyle: {
//     fontFamily: "lato-regular",
//     fontSize: 12,
//     position: "absolute",
//     color: "#747474",
//     alignSelf: "baseline",
//   },
//   codeinView: {
//     //  backgroundColor:'red',
//     height: height * 0.04,
//     width: width * 0.2,
//     // marginTop:25,
//     justifyContent: "flex-end",
//     alignSelf: "center",
//   },
//   RelationInView: {
//     height: height * 0.03,
//     width: width * 0.21,
//     // backgroundColor:'yellow',
//     justifyContent: "flex-start",
//   },
//   bellIconView: {
//     // backgroundColor: 'red',
//     height: height * 0.06,
//     width: width * 0.28,
//     alignSelf: "center",
//     flexDirection: "row",
//   },
//   cardStyle: {
//     height: height * 0.3,
//     width: width * 0.97,
//     alignSelf: "center",
//     // backgroundColor: 'red',
//     //   justifyContent: 'center'
//   },
//   cardStyleinView: {
//     height: height * 0.24,
//     width: width * 0.9,
//     alignSelf: "center",
//     // position:'absolute',
//     // backgroundColor: 'blue',
//     // alignSelf: 'center',
//     justifyContent: "center",
//   },
//   Card_Image: {
//     alignSelf: "center",
//     resizeMode: "contain",
//     height: 195,
//     width: 378,
//     //  position: 'absolute'
//   },
//   soundView: {
//     height: height * 0.05,
//     width: width * 0.97,
//     alignSelf: "center",
//     flexDirection: "row",
//     justifyContent: "center",
//     //  backgroundColor: 'blue',
//     alignItems: "center",
//     borderBottomWidth: 2,
//     borderBottomColor: "#C8C8C8",
//   },
//   soundTextStyle: {
//     fontFamily: "lato-regular",
//     fontSize: 14,
//     color: "#000000",
//     // resizeMode:'contain'
//   },
//   soundImageStyle: {
//     resizeMode: "contain",
//   },
//   soundImageView: {
//     justifyContent: "center",
//     height: height * 0.05,
//     width: width * 0.08,
//     // alignSelf:'center'
//   },
//   soundTextView: {
//     justifyContent: "center",
//     height: height * 0.05,
//     width: width * 0.85,
//     //  backgroundColor: 'green'
//   },
//   arrowView: {
//     height: height * 0.03,
//     width: width * 0.95,
//     // justifyContent: 'space-evenly',
//     flexDirection: "row",
//     //borderWidth: 1,
//     alignSelf: "center",
//     justifyContent: "center",
//     alignItems: "center",
//     // backgroundColor:'blue'
//   },
//   lineTExt: {
//     color: "#C8C8C8",
//     // alignSelf: 'center'
//   },
//   lineImgeStyle: {
//     resizeMode: "contain",
//     alignSelf: "center",
//     height: 15,
//     width: 428,
//   },
//   arrowInView: {
//     height: height * 0.02,
//     width: width * 0.3,
//     justifyContent: "center",
//     alignSelf: "center",
//   },
//   headingTextView: {
//     height: height * 0.05,
//     width: width * 0.95,
//     justifyContent: "center",
//     alignSelf: "center",
//     //  backgroundColor: 'red',
//     shadowColor: "rgb(0,0,0)",
//     shadowOpacity: 0,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//   },
//   headingTextStyle: {
//     alignSelf: "center",
//     color: "#2C723E",
//     fontSize: 18,
//     fontFamily: "lato-regular",
//     fontWeight: "400",
//   },
//   cryptoMainView: {
//     //  borderWidth: 1,
//     height: height * 0.17,
//     justifyContent: "center",
//     width: width * 0.97,
//     alignSelf: "center",
//     flexDirection: "row",
//     backgroundColor: "#E5E5E5",

//     alignSelf: "center",
//     shadowColor: "rgb(0,2,1)",
//     shadowOpacity: 0.1,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//     borderRadius: 10,
//   },
//   cryptoicons: {
//     height: height * 0.03,
//     width: width * 0.2,
//     // alignSelf: 'center',
//     flexDirection: "row",
//     justifyContent: "center",
//     //  backgroundColor:'green',
//     alignItems: "center",
//     // borderBottomWidth: 2,
//     borderBottomColor: "#C8C8C8",
//   },
//   cryptoImageView: {
//     justifyContent: "center",
//     height: height * 0.05,
//     width: width * 0.29,
//     borderWidth: 1,
//     // alignSelf:'center'
//   },
//   iconView: {
//     height: height * 0.16,
//     // borderWidth: 1,
//     width: width * 0.48,
//     borderRadius: 10,
//     justifyContent: "space-evenly",
//     flexDirection: "column",
//     alignSelf: "center",
//   },
//   iconInnerView: {
//     height: height * 0.06,
//     // borderWidth: 1,
//     width: width * 0.4,
//     justifyContent: "center",
//     // alignSelf: 'center',
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#E5E5E5",
//     borderRadius: 10,
//     alignSelf: "center",
//     shadowColor: "rgb(0,2,1)",
//     shadowOpacity: 0.1,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//   },
//   iconInnerView2: {
//     height: height * 0.06,
//     // borderWidth: 1,
//     width: width * 0.4,
//     justifyContent: "center",
//     // alignSelf: 'center',
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#E5E5E5",
//     borderRadius: 10,
//     alignSelf: "center",
//     shadowColor: "rgb(0,2,1)",
//     shadowOpacity: 0.1,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//   },
//   walletTextStyle: {
//     color: "#6A6A6A",
//     fontSize: 11,
//     fontFamily: "lato-regular",
//   },
//   lastmainView: {
//     height: height * 0.57,
//     width: width * 0.97,
//     justifyContent: "center",
//     borderTopLeftRadius: 5,
//     borderTopRightRadius: 5,
//     backgroundColor: "#E5E5E5",

//     alignSelf: "center",
//     shadowColor: "rgb(0,2,1)",
//     shadowOpacity: 0.1,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//   },
//   inviteTextView: {
//     height: height * 0.02,
//     width: width * 0.95,
//     justifyContent: "center",
//   },
//   inviteTextStyle: {
//     fontFamily: "lato-regular",
//     color: "#6A6A6A",
//     fontSize: 14,
//     //alignSelf:'baseline'
//   },
//   earningVIew: {
//     height: height * 0.04,
//     width: width * 0.95,
//     justifyContent: "center",
//   },
//   earningText: {
//     fontFamily: "lato-regular",
//     color: "#2C723E",
//     fontSize: 20,
//     fontWeight: "700",
//   },
//   paraTextView: {
//     height: height * 0.04,
//     width: width * 0.95,
//     justifyContent: "center",
//   },
//   paraTextStyle: {
//     fontFamily: "lato-regular",
//     color: "#6A6A6A",
//     fontSize: 14,
//     fontWeight: "400",
//   },
//   TextView: {
//     // borderWidth: 1,
//     height: height * 0.17,
//     width: width * 0.95,
//     flexDirection: "row",
//     // backgroundColor:'blue'
//   },
//   TextInnerView: {
//     flexDirection: "row",
//     height: height * 0.05,
//     width: width * 0.45,
//     //  borderWidth: 1,
//     // justifyContent: 'center'
//   },
//   textstyle: {
//     fontFamily: "lato-regular",
//     color: "#2C723E",
//     fontSize: 14,
//     fontWeight: "400",
//     alignSelf: "center",
//   },
//   textstyle1: {
//     fontFamily: "lato-regular",
//     color: "#6A6A6A",
//     fontSize: 12,
//     fontWeight: "400",
//     alignSelf: "center",
//   },
//   Earn_Image: {
//     justifyContent: "center",
//     alignItems: "center",
//     height: height * 0.17,
//     width: width * 0.4,
//     // backgroundColor:'yellow',
//     alignSelf: "center",
//   },
//   Earn_ImageStyle: {
//     resizeMode: "contain",
//     height: 132,
//     width: 132,
//   },
//   linkView: {
//     height: height * 0.12,
//     width: width * 0.9,
//     //  borderWidth: 1,
//     alignSelf: "center",
//     flexDirection: "row",
//     // backgroundColor:'grey'
//     backgroundColor: "#E5E5E5",
//     borderRadius: 10,
//     alignSelf: "center",
//     shadowColor: "rgb(0,2,1)",
//     shadowOpacity: 0.1,
//     shadowOffset: {
//       width: 0.5,
//       height: 0.5,
//     },
//   },
//   LinkText1: {
//     fontFamily: "lato-regular",
//     color: "#6A6A6A",
//     fontSize: 12,
//     fontWeight: "400",
//     alignSelf: "center",
//   },
//   LinkText2: {
//     fontFamily: "lato-regular",
//   },
//   linkInnerView: {
//     height: height * 0.07,
//     width: width * 0.60,
//     // borderWidth: 1,
//     alignSelf: 'center',
//     flexDirection: 'row',
//     shadowColor: 'rgb(0,2,1)',
//     shadowOpacity: 0.2,
//     shadowOffset: {
//         width: 0.5,
//         height: 0.5,
//         // backgroundColor: '#E5E5E5',
//         borderRadius: 10,
//         backgroundColor: 'red'
//     },
//     borderRadius: 10
// },
// linkInnerView1: {
//     height: height * 0.060,
//     width: width * 0.25,
//     //  borderWidth: 1,
//     alignSelf: 'center',
//     flexDirection: 'column',
//     justifyContent: 'space-between'

// },
// });
