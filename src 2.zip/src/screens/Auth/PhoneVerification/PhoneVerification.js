import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
} from "react-native";
import react, { useState } from "react";
import { IMAGEPATH } from "../../../assets/icon";
import { Dropdown } from "react-native-material-dropdown";
import PhoneVerificationOtp from "../PhoneVerificationOtp/PhoneVerificationOtp";
const { height, width } = Dimensions.get("window");

const PhoneVerification = (props) => {
  let data = [
    {
      value: "Banana",
    },
    {
      value: "Mango",
    },
    {
      value: "Pear",
    },
  ];
  const [phone, setPhone] = useState("");
  const [errorPhone, setErrorPhone] = useState("");

  const phoneValidate = (phone) => {
    var Regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (phone === "" || phone === undefined || phone === null) {
      setErrorPhone("please enter phone number");
    } else if (!Regex.test(phone)) {
      setErrorPhone("please enter valid number");
    } else {
      setErrorPhone(null);
    }
  };

  const validate = () => {
    var Regx3 = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    var Regx5 =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;

    const flag = true;

    if (phone === "") {
      setErrorPhone("*please enter phone number");
      return !flag;
    }
    if (phone === "" || phone === undefined || phone === null) {
      setErrorPhone("*Please enter phone number");
      return !flag;
    }
    if (!Regx3.test(phone)) {
      setErrorPhone("*Please enter valid Phone number");
      return !flag;
    } else setErrorPhone(null);
  };

  const onSubmit = () => {
    if (validate()) {
      //   alert('Sussessful')
      props.navigation.navigate("PhoneVerificationOtp");
    } else {
      alert("Something went wrong");
    }
  };

  return (
    <View style={styles.MainConatiner}>
      <View style={styles.headerButton}>
        <TouchableOpacity onPress={() => props.navigation.navigate("Register")}>
          <Image
            source={require("../../../assets/images/login/backarrow/backarrow.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => props.navigation.navigate(PhoneVerification)}
        >
          <Image
            source={require("../../../assets/images/login/cross/cross.png")}
          />
        </TouchableOpacity>
      </View>
      <View style={styles.Tital}>
        <Text
          style={{
            fontSize: height / 40,
            fontWeight: "bold",
          }}
        >
          Enter Phone Number
        </Text>
      </View>
      <View style={styles.Tital2}>
        <Text>Enter your phone number to be used for your account.</Text>
      </View>
      <View style={styles.mail}>
        <Text
          style={{
            fontSize: height / 45,
          }}
        >
          Phone Number
        </Text>
      </View>
      <View style={styles.TxtInputMainV}>
        <View style={styles.TxtInput}>
          <View style={styles.emailImg}>
            <Image source={IMAGEPATH.INDIA_IMAGE} />
          </View>
          <View style={styles.DropDown}>
            <Dropdown label="+91" data={data} />
          </View>
          <View style={styles.TxtInputV}>
            <TextInput
              placeholder="Enter your email"
              placeholderTextColor={"#BCBCBC"}
              keyboardType="numeric"
              maxLength={12}
              onChangeText={(text) => {
                setPhone(text), phoneValidate(text);
              }}
            />
          </View>
        </View>
        {errorPhone !== null ? (
          <View
            style={{
              height: "25%",
              width: "80%",
              // alignSelf:'center',
              // backgroundColor: 'green',
            }}
          >
            <Text style={{ color: "red", fontSize: 16 }}>{errorPhone}</Text>
          </View>
        ) : null}
      </View>
      <View style={styles.Button}>
        <TouchableOpacity onPress={() => onSubmit("PhoneVerification")}>
          <View style={styles.Touchable}>
            <Text style={{ color: "#FFFFFF" }}> Next</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default PhoneVerification;

const styles = StyleSheet.create({
  MainConatiner: {
    height: height * 1,
    width: width * 1,
    // backgroundColor: "skyblue",
  },
  headerButton: {
    height: height * 0.08,
    width: width * 0.93,
    // backgroundColor: "red",
    alignSelf: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  Tital: {
    height: height * 0.044,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "yellow",
    justifyContent: "center",
  },
  Tital2: {
    height: height * 0.1,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "red",
  },
  mail: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "green",
    justifyContent: "center",
    fontFamily: "Lato",
  },
  TxtInputMainV: {
    height: height * 0.1,
    width: width * 0.9,
    // backgroundColor: "cyan",
    // justifyContent:'center',
    alignSelf: "center",
  },
  TxtInput: {
    height: height * 0.07,
    width: width * 0.9,
    borderWidth: 0.2,
    borderRadius: 7,
    backgroundColor: "white",
    flexDirection: "row",
    alignItems: "center",

    borderColor: "rgb( 204,198,204)",
    shadowColor: "#000000",
    shadowRadius: 5,
    shadowOffset: {
      height: 0.5,
      width: 0.5,
    },
    shadowOpacity: 0.1,
    backgroundColor: "#FFFFFF",
  },
  emailImg: {
    height: height * 0.045,
    width: width * 0.08,
    // backgroundColor: "red",
    alignItems: "center",
  },
  TxtInputV: {
    height: height * 0.04,
    width: width * 0.68,
    // backgroundColor: "yellow",
    justifyContent: "center",
    padding: 4,
    justifyContent: "center",
    borderLeftWidth: 0.5,
    borderColor: "#343434",
  },
  Button: {
    height: height * 0.17,
    width: width * 1,
    // backgroundColor: "blue",
    justifyContent: "flex-end",
  },
  Touchable: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2C723E",
    borderRadius: 7,
  },
  DropDown: {
    height: height * 0.06,
    width: width * 0.12,
    // backgroundColor: "red",
    justifyContent: "flex-end",
  },
});
