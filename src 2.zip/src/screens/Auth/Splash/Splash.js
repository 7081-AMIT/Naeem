import {
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  Image,
  ImageBackground,
  View,
} from "react-native";
import React, { useEffect, useState } from "react";
import { IMAGEPATH } from "../../../assets/icon";

const { height, width } = Dimensions.get("window");
const Splash = (props) => {
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    setTimeout(function () {
      props.navigation.navigate('Login');
    //   alert("This is Splash");
      setIsVisible(true);
    }, 3000);
  }, []);

  return (
    <View style={styles.main}>
      <SafeAreaView>
          <View style={styles.Imag}>
            <Image
              style={{ height: 130, width: 130,resizeMode:'contain' }}
              source={IMAGEPATH.SPLASH_IMAGE}
              // source={require('../../../assets/images/splash/splash.png')}
            />
        </View>
      </SafeAreaView>
    </View>
  );
};

export default Splash;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
    //   justifyContent:'center'
    // backgroundColor: 'cyan'
  },
  Image: {
    height: height * 0.23,
    width: width * 0.65,
    //   backgroundColor: 'cyan',
    justifyContent: "center",
    alignSelf: "center",
    alignItems: "center",
  },
  cen: {
    height: height * 0.8,
    width: width * 0.65,
    // backgroundColor: 'pink',
    justifyContent: "center",
    alignSelf: "center",
    alignItems: "center",
  },
  Imag: {
    height: height * 0.8,
    width: width * 0.65,
    // backgroundColor: 'pink',
    justifyContent: "center",
    alignSelf: "center",
    alignItems: "center",
  },
});
