import {
  StyleSheet,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  SafeAreaView,
  View,
} from "react-native";
import React from "react";
import { IMAGEPATH } from "../../../assets/icon";
import { COLORS } from "../../../utils/Color";

const { height, width } = Dimensions.get("window");
const Document = (props) => {
  return (
    <SafeAreaView>
      <View style={styles.main}>
        <View style={styles.bgcimg}>
          <View style={styles.backimg}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate("Selfie")}
            >
              <Image
                style={{ height: 50, width: 50, resizeMode: "contain" }}
                source={IMAGEPATH.AROW_IMAGE}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.crossimg}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate("Identity")}
            >
              <Image
                style={{ height: 15, width: 15, resizeMode: "contain" }}
                source={IMAGEPATH.CROSS_IMAGE}
              />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.box}>
          <Image
            style={{ height: 80, width: 80, resizeMode: "contain" }}
            source={IMAGEPATH.CLICK_IMAGE}
          />
        </View>
        <View style={styles.text}>
          <Text
            style={{
              color: "#000000",
              fontSize: height / 55,
              fontWeight: "500",
            }}
          >
            Document Uploaded
          </Text>
        </View>
        <View style={styles.text1}>
          <Text
            style={{
              color: "#547597",
              fontSize: height / 60,
              fontWeight: "500",
            }}
          >
            Click Continue to add selfie of yourself
          </Text>
        </View>
        <View style={styles.btncon}>
       <TouchableOpacity onPress={() =>props.navigation.navigate('Selfie2')}>
       <View style={styles.btn}>
       <Text style={{fontSize:18,color:'#FFFFFF',fontWeight:'400'}}>Continue</Text>
       </View>
       </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Document;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
  },
  bgcimg: {
    height: height * 0.1,
    width: width * 0.95,
    alignSelf: "center",
    alignItems: "center",
    // backgroundColor:'cyan',
    flexDirection: "row",
    justifyContent: "space-between",
  },
  backimg: {
    height: height * 0.05,
    justifyContent: "center",
    alignItems: "flex-start",
    width: width * 0.2,
    // backgroundColor: "cyan",
  },
  crossimg: {
    height: height * 0.05,
    width: width * 0.1,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },
  box: {
    height: height * 0.3,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "flex-end",
    // backgroundColor: "green"
  },
  text: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "flex-end",
    alignItems: "center",
  },
  text1: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
  },
  btncon:{
    height: height * 0.27,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: 'flex-end',
    alignItems: "center",
    // backgroundColor:'pink'
  },
  btn:{
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    borderRadius:7,
    backgroundColor:"#2C723E"
  }
});
