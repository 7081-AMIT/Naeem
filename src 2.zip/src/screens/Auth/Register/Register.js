import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  TextInput,
  TouchableOpacity,
} from "react-native";
import react, { useState } from "react";
import PhoneVerification from "../PhoneVerification/PhoneVerification";
import PhoneVerificationOtp from "../PhoneVerificationOtp/PhoneVerificationOtp";
const { height, width } = Dimensions.get("window");

const Register = (props) => {
  const [check1, setCheck1] = useState(false);

  const [isChecked, setIsChecked] = useState(false);
  const toggle = () => {
    setIsChecked(false);
  };
  const _toggle = () => {
    setIsChecked(true);
  };

  // ****Validation***
  const [isSecureEntry, setIsSecureEntry] = useState(true);

  const [email, setEmail] = useState("");
  const [errorEmail, setErrorEmail] = useState("");

  const [password, setPasssword] = useState("");
  const [errorPassword, setErrorPassword] = useState("");

  const emailValidate = (email) => {
    var Regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email === "" || email === undefined || email === null) {
      setErrorEmail("please enter email");
    } else if (!Regex.test(email)) {
      setErrorEmail("please enter valid email");
    } else {
      setErrorEmail(null);
    }
  };

  const passwordValidate = (password) => {
    var Regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    if (password === "" || password === undefined || password === null) {
      setErrorPassword("please enter password");
    } else if (!Regex.test(password)) {
      setErrorPassword("please enter valid password");
    } else {
      setErrorPassword(null);
    }
  };

  const validate = () => {
    var Regx3 = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    var Regx5 =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;

    const flag = true;

    if (password === "" || password === undefined || password === null) {
      setErrorPassword("*Please enter password");
      return !flag;
    }
    if (!Regx5.test(password)) {
      setErrorPassword("*Please enter valid password");
      return !flag;
    } else setErrorPassword(null);
    return flag;
  };

  //step - 4;

  const onSubmit = () => {
    if (validate()) {
      // alert('Sussessful')
      props.navigation.navigate("Email");
    } else {
      alert("Something went wrong");
    }
  };

  return (
    <View style={styles.MainConatiner}>
      <View style={styles.headerButton}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Login")}
        >
          <Image
            source={require("../../../assets/images/login/backarrow/backarrow.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity >
          <Image
            // source={require("../../../assets/images/login/cross/cross.png")}
          />
        </TouchableOpacity>
      </View>
      <View style={styles.Tital}>
        <Text
          style={{
            fontSize: height / 40,
            fontWeight: "bold",
            color:'black'
          }}
        >
          Enter Account Details
        </Text>
      </View>
      <View style={styles.mail}>
        <Text
          style={{
            fontSize: height / 45,
            color:'#343434'
          }}
        >
          Email
        </Text>
      </View>
      <View style={styles.TxtInputMainV}>
        <View style={styles.TxtInput}>
          <View style={styles.emailImg}>
            <Image
              source={require("../../../assets/images/login/mail/mail.png")}
            />
          </View>
          <View style={styles.TxtInputV}>
            <TextInput
              placeholder="Enter your email"
              placeholderTextColor={"#BCBCBC"}
              // color={"black"}
              keyboardType="email-address"
              maxLength={64}
              onChangeText={(text) => {
                setEmail(text), emailValidate(text);
              }}
            />
          </View>
        </View>
        {errorEmail !== null ? (
          <View
            style={{
              height: "28%",
              width: "80%",
              // alignSelf:'center',
              justifyContent: "center",
              // backgroundColor: 'green',
            }}
          >
            <Text style={{ color: "red", fontSize: 16 }}>{errorEmail}</Text>
          </View>
        ) : null}
      </View>

      <View style={styles.mail}>
        <Text
          style={{
            fontSize: height / 45,
            color:'#343434'
          }}
        >
          Password
        </Text>
      </View>
      <View style={styles.TxtInputMainV}>
        <View style={styles.TxtInput}>
          <View style={styles.emailImg}>
            <Image
              source={require("../../../assets/images/login/lock/lock.png")}
            />
          </View>
          <View style={styles.TxtInputV}>
            <TextInput
              placeholder="Enter your password"
              placeholderTextColor={"#BCBCBC"}
              keyboardType="default"
              secureTextEntry={isSecureEntry}
              maxLength={28}
              onChangeText={(text) => {
                setPasssword(text), passwordValidate(text);
              }}
            />
          </View>
          <View style={styles.eyeImg}>
            <TouchableOpacity
              onPress={() => {
                setIsSecureEntry((prev) => !prev);
              }}
            >
              <Image
                source={require("../../../assets/images/login/eye/eye.png")}
              />
            </TouchableOpacity>
          </View>
        </View>
        {errorPassword !== null ? (
          <View
            style={{
              height: "28%",
              width: "80%",
              // alignSelf:'center',
              // backgroundColor: 'green',
            }}
          >
            <Text style={{ color: "red", fontSize: 16 }}>{errorPassword}</Text>
          </View>
        ) : null}
      </View>
      <View style={styles.check}>
        <View style={{ flexDirection: "row" }}>
          <TouchableOpacity onPress={() => (isChecked ? toggle() : _toggle())}>
            <Image
              source={
                isChecked
                  ? require("../../../assets/images/register/circlegreen/circlegreen.png")
                  : require("../../../assets/images/register/circle/circle.png")
              }
              style={{ height: 25, width: 25, borderRadius: 6 }}
            />
          </TouchableOpacity>
          <View style={styles.ttx}>
            <Text style={{ color: "#343434" }}>
              I agree to receive email updates from Company
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.check}>
        <View style={{ flexDirection: "row" }}>
          <TouchableOpacity onPress={() => (isChecked ? toggle() : _toggle())}>
            <Image
              source={
                isChecked
                  ? require("../../../assets/images/register/circle/circle.png")
                  : require("../../../assets/images/register/circlegreen/circlegreen.png")
              }
              style={{ height: 25, width: 25, borderRadius: 6 }}
            />
          </TouchableOpacity>
          <View style={styles.ttx1}>
            <Text style={{ color: "#343434" }}>
              I agree to Terms and Conditions
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.Button}>
        <TouchableOpacity onPress={() => onSubmit("")}>
          <View style={styles.Touchable}>
            <Text style={{ fontSize:width/25,fontWeight:'500', color: "#FFFFFF" }}> Next</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Register;

const styles = StyleSheet.create({
  MainConatiner: {
    height: height * 1,
    width: width * 1,
    // backgroundColor: "skyblue",
  },
  headerButton: {
    height: height * 0.1,
    width: width * 0.92,
    // backgroundColor: "red",
    alignSelf: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  Tital: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "yellow",
    justifyContent: "center",
  },
  mail: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "red",
    justifyContent: "center",
  },
  TxtInputMainV: {
    height: height * 0.1,
    width: width * 0.9,
    // backgroundColor: "cyan",
    borderRadius:7,
    // justifyContent:'center',
    alignSelf: "center",
  },
  TxtInput: {
    height: height * 0.07,
    width: width * 0.9,
    // borderWidth: 0.2,
    borderRadius: 8,
    // backgroundColor: "green",
    flexDirection: "row",
    alignItems: "center",

    // borderColor: "rgb( 204,198,204)",
    // shadowColor: "#000000",
    // shadowRadius: 5,
    // shadowOffset: {
      // height: 0.5,
      // width: 0.5,
    // },
    // shadowOpacity: 0.1,
    backgroundColor: "#FFFFFF",
  },
  emailImg: {
    height: height * 0.045,
    width: width * 0.12,
    // backgroundColor: "red",
    alignItems: "center",
    justifyContent: "center",
    borderRightWidth: 0.5,
    borderColor: "#BCBCBC",
  },
  eyeImg: {
    height: height * 0.045,
    width: width * 0.12,
    // backgroundColor: "red",
    alignItems: "center",
    justifyContent: "center",
  },
  TxtInputV: {
    height: height * 0.05,
    width: width * 0.65,
    // backgroundColor: "yellow",
    justifyContent: "center",
    // padding: 2,
  },
  check: {
    height: height * 0.06,
    width: width * 0.9,
    // backgroundColor: "red",
    alignSelf: "center",
    justifyContent: "center",
  },
  ttx: {
    height: height * 0.03,
    width: width * 0.84,
    // backgroundColor: "yellow",
    justifyContent: "center",
    alignItems: "center",
  },
  ttx1: {
    height: height * 0.03,
    width: width * 0.58,
    // backgroundColor: "yellow",
    justifyContent: "center",
    alignItems: "center",
  },
  Button: {
    height: height * 0.1,
    width: width * 1,
    // backgroundColor: "blue",
    justifyContent: "center",
  },
  Touchable: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2C723E",
    borderRadius: 7,
  },
});
