import {
  StyleSheet,
  Text,
  SafeAreaView,
  Image,
  Dimensions,
  TouchableOpacity,
  View,
} from "react-native";
import React from "react";
import { IMAGEPATH } from "../../../assets/icon";
import { COLORS } from "../../../utils/Color";
import * as Progress from "react-native-progress";

const { height, width } = Dimensions.get("window");
const Selfie = (props) => {
  return (
    <SafeAreaView>
      <View style={styles.main}>
        <View style={styles.bgcimg}>
          <View style={styles.backimg}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate("Driver")}
            >
              <Image
                style={{ height: 50, width: 50, resizeMode: "contain" }}
                source={IMAGEPATH.AROW_IMAGE}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.crossimg}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate("Identity")}
            >
              <Image
                style={{ height: 15, width: 15, resizeMode: "contain" }}
                source={IMAGEPATH.CROSS_IMAGE}
              />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.text}>
          <Text style={styles.tt1}>Identity Verification</Text>
        </View>
        <View style={styles.txt}>
          <Text
            style={{
              fontSize: height / 55,
              fontWeight: "500",
              color: "#000000",
            }}
          >
            Take a Selfie
          </Text>
        </View>
        <View style={styles.txt1}>
          <Text
            style={{
              fontSize: height / 58,
              fontWeight: "400",
              color: "#000000",
            }}
          >
            Example
          </Text>
        </View>
        <View style={styles.imgcon}>
          <View style={styles.img}>
            <Image
              style={{ height: 110, width: 105, resizeMode: "contain" }}
              source={IMAGEPATH.SELFIE_IMAGE}
            />
          </View>
        </View>
        <View style={styles.imgtcom}>
          <View style={styles.rimg}>
            <Image
              style={{ height: 15, width: 13, resizeMode: "contain" }}
              source={IMAGEPATH.RIGHT_IMAGE}
            />
          </View>
          <View style={styles.tet}>
            <Text
              style={{
                fontSize: height / 60,
                color: "#000000",
                fontWeight: "400",
              }}
            >
              Take Selfie of yourself with a neutral expresion
            </Text>
          </View>
        </View>

        <View style={styles.imgtcom}>
          <View style={styles.rimg}>
            <Image
              style={{ height: 15, width: 13, resizeMode: "contain" }}
              source={IMAGEPATH.RIGHT_IMAGE}
            />
          </View>
          <View style={styles.tet}>
            <Text
              style={{
                fontSize: height / 60,
                color: "#000000",
                fontWeight: "400",
              }}
            >
              Mack sure your whole face is visible, centered and your eyes are
              open
            </Text>
          </View>
        </View>

        <View style={styles.imgtcom}>
          <View style={styles.rimg}>
            <Image
              style={{ height: 15, width: 13, resizeMode: "contain" }}
              source={IMAGEPATH.RED_IMAGE}
            />
          </View>
          <View style={styles.tet}>
            <Text
              style={{
                fontSize: height / 60,
                color: "#000000",
                fontWeight: "400",
              }}
            >
              Do not crop your ID or use screeshot of Id
            </Text>
          </View>
        </View>

        <View style={styles.imgtcom}>
          <View style={styles.rimg}>
            <Image
              style={{ height: 15, width: 13, resizeMode: "contain" }}
              source={IMAGEPATH.RED_IMAGE}
            />
          </View>
          <View style={styles.tet}>
            <Text
              style={{
                fontSize: height / 60,
                color: "#000000",
                fontWeight: "400",
              }}
            >
              Do not hide or alter parts of your face (No
              hat/beauty/fukters/geadger)
            </Text>
          </View>
        </View>
        <View style={styles.textimg}>
          <Text
            style={{
              fontSize: height / 60,
              color: "#000000",
              fontWeight: "500",
            }}
          >
          File size must between 10KB and 5120KB in .jpg/ .jpeg/ .png format.          </Text>
        </View>
        <View style={styles.prog}>
        <Progress.Bar
          progress={0.7}
          width={200}
          height={1.8}
          useNativeDriver={true}
          color={"#2C723E"}
          indeterminateAnimationDuration={10}
        />
        {/*<Progress.Pie progress={0.4} size={50} />
    <Progress.Circle size={30} indeterminate={true} />
<Progress.CircleSnail color={["red", "green", "blue"]} /> */}
      </View>
      <View style={styles.btncon}>
  <TouchableOpacity onPress={() =>props.navigation.navigate('Driver')}>
  <View style={styles.verify}>
  <Text style={{fontSize:18,color:'#FFFFFF',fontWeight:'700'}}>Previous</Text>
  </View>
  </TouchableOpacity>
 <TouchableOpacity onPress={() =>props.navigation.navigate('Document')}>
 <View style={styles.continue}>
 <Text style={{fontSize:18,color:'#FFFFFF',fontWeight:'700'}}>Continue</Text>
 </View>
 </TouchableOpacity>
  </View>
      </View>
      </SafeAreaView>
  );
};

export default Selfie;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
  },
  bgcimg: {
    height: height * 0.1,
    width: width * 0.95,
    alignSelf: "center",
    alignItems: "center",
    // backgroundColor:'cyan',
    flexDirection: "row",
    justifyContent: "space-between",
  },
  backimg: {
    height: height * 0.05,
    justifyContent: "center",
    alignItems: "flex-start",
    width: width * 0.2,
    // backgroundColor: "cyan",
  },
  crossimg: {
    height: height * 0.05,
    width: width * 0.1,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },
  text: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    //   backgroundColor:'cyan'
  },
  tt1: {
    fontSize: height / 35,
    fontWeight: "600",
    color: "#000000",
    fontFamily: "Lato-Regular",
  },
  txt: {
    height: height * 0.04,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'cyan'
  },
  txt1: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'cyan'
  },
  imgcon: {
    height: height * 0.15,
    width: width * 0.9,
    alignSelf: "center",
  },
  img: {
    height: height * 0.14,
    width: width * 0.35,
    //   backgroundColor:'cyan'
  },
  imgtcom: {
    height: height * 0.05,
    width: width * 0.9,
    justifyContent: "center",
    alignSelf: "center",
    flexDirection: "row",
    //   backgroundColor:'cyan'
  },
  rimg: {
    height: height * 0.05,
    width: width * 0.07,
    justifyContent: "center",
    alignSelf: "center",
    // backgroundColor:'green'
  },
  tet: {
    height: height * 0.05,
    width: width * 0.83,
    justifyContent: "center",
    alignSelf: "center",
    // backgroundColor:'pink'
  },
  textimg: {
    height: height * 0.1,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'green'
  },
  prog: {
    height: height * 0.04,
    width: width * 0.9,
    alignItems: "center",
    justifyContent: "flex-end",
    alignSelf: "center",
    // backgroundColor: "pink",
  },
  btncon:{
    height:height*0.12,
    width:width*0.9,
    alignSelf:'center',
    alignItems:'center',
    justifyContent:'space-between',
    flexDirection:'row',
    // backgroundColor:'cyan'
},
verify:{
    height:height*0.07,
    width:width*0.4,
    alignSelf:'center',
    alignItems:'center',
    borderRadius:7,
    justifyContent:'center',
    backgroundColor:'#7C7C7C'
},
continue:{
    height:height*0.07,
    width:width*0.4,
    alignItems:'center',
    alignSelf:'center',
    borderRadius:7,
    justifyContent:'center',
    backgroundColor:'#2C723E'
},
});
