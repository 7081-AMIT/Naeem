import {
  StyleSheet,
  Text,
  SafeAreaView,
  TextInput,
  Image,
  Dimensions,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useState } from "react";
import { IMAGEPATH } from "../../../assets/icon";
import { COLORS } from "../../../utils/Color";
import { Dropdown } from "react-native-material-dropdown";
const { height, width } = Dimensions.get("window");

const data = [
  {
    value: "+92",
  },
  {
    value: "+1",
  },
];

const Login = (props) => {
  const [isChecked, setIsChecked] = useState(false);
  const toggle = () => {
    setIsChecked(true);
  };
  const _toggle = () => {
    setIsChecked(false);
  };

  const [isChecked1, setIsChecked1] = useState(false);
  const toggle1 = () => {
    setIsChecked1(true);
  };
  const _toggle1 = () => {
    setIsChecked1(false);
  };

  const [isSecureEntry, setIsSecureEntry] = useState(true);

  const [selectedString, setSelectedString] = useState("Email");

  const [email, setEmail] = useState("");
  const [errorEmail, setErrorEmail] = useState("");

  const [password, setPassword] = useState("");
  const [errorPassword, setErrorPassword] = useState("");

  const [password1, setPassword1] = useState("");
  const [errorPassword1, setErrorPassword1] = useState("");

  const [phone, setPhone] = useState("");
  const [errorPhone, setErrorPhone] = useState("");

  const phoneValidate = (phone) => {
    var Regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (phone === "" || phone === undefined || phone === null) {
      setErrorPhone("*please enter phone number");
    } else if (!Regex.test(phone)) {
      setErrorPhone("*please enter vaid number");
    } else {
      setErrorPhone(null);
    }
  };

  const emailValidate = (email) => {
    var Regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email === "" || email === undefined || email === null) {
      setErrorEmail("*please enter email");
    } else if (!Regex.test(email)) {
      setErrorEmail("*Please enter valid email");
    } else {
      setErrorEmail(null);
    }
  };

  const passwordValidate = (password) => {
    var Regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    if (password === "" || password === undefined || password === null) {
      setErrorPassword("*Please enter password");
    } else if (!Regex.test(password)) {
      setErrorPassword("*Please enter valid password");
    } else {
      setErrorPassword(null);
    }
  };

  const password1Validate = (password1) => {
    var Regex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    if (password1 === "" || password1 === undefined || password1 === null) {
      setErrorPassword1("*Please enter password");
    } else if (!Regex.test(password1)) {
      setErrorPassword1("*Please enter valid password");
    } else {
      setErrorPassword1(null);
    }
  };

  const validate = () => {
    var Rgex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    var Regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    const flag = true;
    if (email === "") {
      setErrorEmail("*please enter email");
      return !flag;
    }
    if (email === "" || email === undefined || email === null) {
      setErrorEmail("*please enter email");
      return !flag;
    }
    if (!Regex.test(email)) {
      setErrorEmail("*please enter valid email");
      return !flag;
    } else setErrorEmail(null);

    if (password === "") {
      setErrorPassword("*Please enter password");
      return !flag;
    }
    if (password === "" || password === undefined || password === null) {
      setErrorPassword("*Please enter password");
      return !flag;
    }
    if (!Rgex.test(password)) {
      setErrorPassword("*Please enter valid password");
      return !flag;
    } else {
      setErrorPassword(null);
    }
    return flag;
  };

  const validate1 = () => {
    var Rgx = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    var Regx =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/;
    const flag = true;
    if (phone === "") {
      setErrorPhone("*please enter phone number");
      return !flag;
    }
    if (phone === "" || phone === undefined || phone === null) {
      setErrorPhone("*Please enter phone number");
      return !flag;
    }
    if (!Rgx.test(phone)) {
      setErrorPhone("*Please enter valid Phone number");
      return !flag;
    } else setErrorPhone(null);
    if (password1 === "") {
      setErrorPassword1("*please enter password");
      return !flag;
    }
    if (password1 === "" || password1 === undefined || password1 === null) {
      setErrorPassword1("*please enter password");
      return !flag;
    }
    if (!Regx.test(password1)) {
      setErrorPassword1("*please enter valid password");
      return !flag;
    } else {
      setErrorPassword1(null);
    }
    return flag;
  };

  const onSubmit = () => {
    if (validate()) {
      alert("Sussessful");
      // props.navigation.navigate("Phone");
    } else {
      alert("Something went wrong");
    }
  };

  const onSubmit1 = () => {
    if (validate1()) {
      alert("Sussessful");
      // props.navigation.navigate("Phone");
    } else {
      alert("Something went wrong");
    }
  };

  return (
    <SafeAreaView>
      <View style={styles.main}>
        <View style={styles.cross}>
          <TouchableOpacity onPress={() => props.navigation.navigate("Home")}>
            <Image
              style={{ height: 15, width: 15, resizeMode: "contain" }}
              source={IMAGEPATH.CROSS_IMAGE}
            />
          </TouchableOpacity>
        </View>
        <View style={styles.text}>
          <Text
            style={{
              fontSize: height / 35,
              fontWeight: "600",
              color: "#000000",
              fontFamily: "Lato-Regular",
            }}
          >
            Company Account Login
          </Text>
        </View>
        {/* ******************** Tab Container *************** */}

        <View style={styles.tabcontainer}>
          <View style={styles.DetailsAndItemActivityContainer}>
            <TouchableOpacity onPress={() => setSelectedString("Email")}>
              <View
                style={[
                  styles.DetailsTabContainer,
                  {
                    backgroundColor:
                      selectedString === "Email" ? COLORS.TOP_TAB : null,
                    // borderRadius: selectedString === "Email" ? 35 : 0,
                  },
                ]}
              >
                <Text
                  style={{
                    fontSize: 16,
                    color: selectedString === "Email" ? COLORS.WHITE : "black",
                  }}
                >
                  Email
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => setSelectedString("Phone")}>
              <View
                style={[
                  styles.DetailsTabContainer,
                  {
                    backgroundColor:
                      selectedString === "Phone" ? COLORS.TOP_TAB : null,
                    // borderRadius: selectedString === "Phone" ? 35 : 0,
                  },
                ]}
              >
                <Text
                  style={{
                    fontSize: height / 65,
                    color: selectedString === "Phone" ? COLORS.WHITE : "black",
                  }}
                >
                  Phone Number
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* ********* Body ******** */}

        {selectedString === "Email" ? (
          <View style={[styles.MyBundleListContainer]}>
            <View style={styles.HeadingTxtContainer}>
              <View style={styles.ttx}>
                <Text
                  style={{ fontSize: 18, fontWeight: "400", color: "#343434" }}
                >
                  Email
                </Text>
              </View>
            </View>
            <View style={styles.txtinpt}>
              <View style={styles.inpt}>
                <View style={styles.imge}>
                  <View style={styles.bgimg}>
                    <Image
                      style={{ height: 15, width: 15, resizeMode: "contain" }}
                      source={IMAGEPATH.MAIL_IMAGE}
                    />
                  </View>
                </View>
                <View style={styles.txtemail}>
                  <View style={styles.ttx1}>
                    <TextInput
                      style={{ fontSize: 16, color: "black" }}
                      placeholder="Enter your email"
                      placeholderTextColor={"#BCBCBC"}
                      keyboardType="email-address"
                      maxLength={60}
                      onChangeText={(text) => {
                        setEmail(text), emailValidate(text);
                      }}
                    />
                  </View>
                </View>
              </View>
              {errorEmail !== null ? (
                <View
                  style={{
                    height: "30%",
                    width: "90%",
                    alignSelf: "center",
                    // backgroundColor: 'green',
                  }}
                >
                  <Text style={{ color: "red", fontSize: 16 }}>
                    {errorEmail}
                  </Text>
                </View>
              ) : null}
            </View>

            <View style={styles.pass}>
              <View style={styles.pss}>
                <Text
                  style={{ fontSize: 18, fontWeight: "400", color: "#343434" }}
                >
                  Password
                </Text>
              </View>
            </View>
            <View style={styles.txtinpt}>
              <View style={styles.inpt1}>
                <View style={styles.imgemail}>
                  <View style={styles.bimg11}>
                    <Image
                      style={{ height: 15, width: 15, resizeMode: "contain" }}
                      source={IMAGEPATH.LOCK_IMAGE}
                    />
                  </View>
                </View>
                <View style={styles.txtpass}>
                  <View style={styles.ttx2}>
                    <View style={styles.ttx3}>
                      <TextInput
                        style={{ fontSize: 16, color: "black" }}
                        placeholder="Enter your password"
                        placeholderTextColor={"#BCBCBC"}
                        secureTextEntry={isSecureEntry}
                        onChangeText={(text) => {
                          setPassword(text), passwordValidate(text);
                        }}
                      />
                    </View>
                    <View style={styles.img2}>
                      <TouchableOpacity
                        onPress={() => {
                          setIsSecureEntry((prev) => !prev);
                          isChecked ? toggle() : _toggle();
                        }}
                      >
                        {/*<Image
           style={{ height: 18, width: 18, resizeMode: "contain" }}
           source={IMAGEPATH.EYE_IMAGE}
        />*/}
                        <Image
                          style={{
                            height: 20,
                            width: 20,
                            resizeMode: "contain",
                          }}
                          // source={require("../../../assets/images/login/eye/eye.png")}
                          source={
                            isChecked
                              ? require("../../../assets/images/login/eye/eye1.png")
                              : require("../../../assets/images/login/eye/eye.png")
                          }
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
              {errorPassword !== null ? (
                <View
                  style={{
                    height: "30%",
                    width: "90%",
                    alignSelf: "center",
                    // backgroundColor: 'green',
                  }}
                >
                  <Text style={{ color: "red", fontSize: 16 }}>
                    {errorPassword}
                  </Text>
                </View>
              ) : null}
            </View>

            <TouchableOpacity
              onPress={() => props.navigation.navigate("ForgotPasswordEmail")}
            >
              <View style={styles.fpass}>
                <Text
                  style={{
                    fontSize: 18,
                    fontWeight: "400",
                    color: "#343434",
                    textDecorationLine: "underline",
                  }}
                >
                  Forgot password?
                </Text>
              </View>
            </TouchableOpacity>

            <View style={styles.btncon}>
              <TouchableOpacity onPress={() => onSubmit()}>
                <View style={styles.btn}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: "600",
                      color: COLORS.WHITE,
                    }}
                  >
                    Log In
                  </Text>
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.reg}>
              <TouchableOpacity
                onPress={() => props.navigation.navigate("Register")}
              >
                <View style={styles.regs}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: "400",
                      color: COLORS.TXT_COLOR,
                      textDecorationLine: "underline",
                    }}
                  >
                    Register now
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={[styles.MyBundleListContainer]}>
            <View style={styles.HeadingTxtContainer}>
              <View style={styles.ttx}>
                <Text
                  style={{
                    fontSize: 18,
                    fontWeight: "400",
                    color: COLORS.TXT_COLOR,
                  }}
                >
                  Phone Number
                </Text>
              </View>
            </View>
            <View style={styles.txtinpt}>
              <View style={styles.inpt}>
                <View style={styles.imgcon}>
                  <View style={styles.img}>
                    <View style={styles.bimg}>
                      <Image
                        style={{ height: 25, width: 25, resizeMode: "contain" }}
                        source={IMAGEPATH.FLAG_IMAGE}
                      />
                    </View>
                  </View>
                  <View style={styles.drop}>
                    <Dropdown label="+91" data={data} />
                  </View>
                </View>
                <View style={styles.txtphone}>
                  <View style={styles.ttx1}>
                    <TextInput
                      style={{ fontSize: 16, color: "black" }}
                      placeholder="Enter your phone number"
                      placeholderTextColor={"#BCBCBC"}
                      keyboardType="email-address"
                      maxLength={10}
                      onChangeText={(text) => {
                        setPhone(text), phoneValidate(text);
                      }}
                    />
                  </View>
                </View>
              </View>
              {errorPhone !== null ? (
                <View
                  style={{
                    height: "30%",
                    width: "90%",
                    alignSelf: "center",
                    // backgroundColor: 'green',
                  }}
                >
                  <Text style={{ color: "red", fontSize: 16 }}>
                    {errorPhone}
                  </Text>
                </View>
              ) : null}
            </View>

            <View style={styles.pass}>
              <View style={styles.pss}>
                <Text
                  style={{ fontSize: 18, fontWeight: "400", color: "#343434" }}
                >
                  password
                </Text>
              </View>
            </View>
            <View style={styles.txtinpt}>
              <View style={styles.inpt1}>
                <View style={styles.img1}>
                  <View style={styles.bimg1}>
                    <Image
                      style={{ height: 15, width: 15, resizeMode: "contain" }}
                      source={IMAGEPATH.LOCK_IMAGE}
                    />
                  </View>
                </View>
                <View style={styles.txt11}>
                  <View style={styles.ttx2}>
                    <View style={styles.ttx3}>
                      <TextInput
                        style={{ fontSize: 16, color: "black" }}
                        placeholder="Enter your password"
                        placeholderTextColor={"#BCBCBC"}
                        secureTextEntry={isSecureEntry}
                        onChangeText={(text) => {
                          setPassword1(text), password1Validate(text);
                        }}
                      />
                    </View>
                    <View style={styles.img2}>
                      <TouchableOpacity
                        onPress={() => {
                          setIsSecureEntry((prev) => !prev);
                          isChecked1 ? toggle1() : _toggle1();
                        }}
                      >
                        {/*<Image
           style={{ height: 18, width: 18, resizeMode: "contain" }}
           source={IMAGEPATH.EYE_IMAGE}
        />*/}
                        <Image
                          style={{
                            height: 20,
                            width: 20,
                            resizeMode: "contain",
                          }}
                          // source={require("../../../assets/images/login/eye/eye.png")}
                          source={
                            isChecked1
                              ? require("../../../assets/images/login/eye/eye1.png")
                              : require("../../../assets/images/login/eye/eye.png")
                          }
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
              {errorPassword1 !== null ? (
                <View
                  style={{
                    height: "30%",
                    width: "90%",
                    alignSelf: "center",
                    // backgroundColor: 'green',
                  }}
                >
                  <Text style={{ color: "red", fontSize: 16 }}>
                    {errorPassword1}
                  </Text>
                </View>
              ) : null}
            </View>

            <View style={styles.fpass}>
              <TouchableOpacity
                onPress={() => props.navigation.navigate("ForgotPasswordPhone")}
              >
                <View style={styles.fpss}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: "400",
                      color: "#343434",
                      textDecorationLine: "underline",
                    }}
                  >
                    Forgot password?
                  </Text>
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.btncon}>
              <TouchableOpacity onPress={() => onSubmit1()}>
                <View style={styles.btn}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: "600",
                      color: "#FFFFFF",
                    }}
                  >
                    Log In
                  </Text>
                </View>
              </TouchableOpacity>
            </View>

            <View style={styles.reg}>
              <TouchableOpacity
                onPress={() => props.navigation.navigate("Register")}
              >
                <View style={styles.regs}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: "400",
                      color: "#343434",
                      textDecorationLine: "underline",
                    }}
                  >
                    Register now
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
};

export default Login;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
  },
  cross: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "flex-end",
    justifyContent: "center",
    // backgroundColor:'green'
  },
  text: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    //   backgroundColor:'cyan'
  },
  tabcontainer: {
    height: height * 0.12,
    width: width * 1,
    justifyContent: "center",
    alignItems: "flex-end",
    // backgroundColor:'cyan'
  },
  DetailsAndItemActivityContainer: {
    flexDirection: "row",
    alignItems: "center",
    height: height * 0.07,
    width: width * 0.68,
    justifyContent: "space-evenly",
    // backgroundColor: COLORS.TOP_TAB_BACK,
    // borderRadius: 35,
    // borderWidth: 1,
    // borderColor: "#1A1A1A",
  },
  DetailsTabContainer: {
    height: height * 0.05,
    width: width * 0.31, // 0.25
    alignItems: "center",
    borderRadius: 7,
    justifyContent: "center",
  },
  NoDataTxtContainer: {
    height: height * 0.3,
    width: width,
    justifyContent: "center",
    alignItems: "center",
  },
  NoDataTxt: {
    color: COLORS.INPUT_TXT_COLOR,
    fontSize: height / 45,
  },
  MyBundleListContainer: {
    height: height * 0.85,
    width: width * 1,
    //alignItems: "center",
    //justifyContent: "center",
    // backgroundColor:'cyan'
  },
  HeadingTxtContainer: {
    height: height * 0.04,
    width: width * 1,
    // backgroundColor:'blue',
    // justifyContent: "center",
    // alignItems: "center",
  },
  ttx: {
    width: width * 0.9,
    height: height * 0.05,
    //   backgroundColor:"cyan",
    justifyContent: "center",
    alignSelf: "center",
  },
  txtinpt: {
    height: height * 0.1,
    width: width * 1,
    justifyContent: "space-evenly",
    //   alignSelf:'center',
    //   backgroundColor:'green'
  },
  inpt: {
    height: height * 0.06,
    width: width * 0.9,
    borderWidth: 0.3,
    borderColor: "#BCBCBC",
    // backgroundColor:'green',
    alignSelf: "center",
    flexDirection: "row",
  },
  inpt1: {
    height: height * 0.06,
    width: width * 0.9,
    borderWidth: 0.5,
    borderColor: "#000000",
    // backgroundColor:'green',
    alignSelf: "center",
    flexDirection: "row",
  },
  img: {
    height: height * 0.06,
    width: width * 0.1,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor:'yellow'
  },
  imgemail: {
    height: height * 0.06,
    width: width * 0.12,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor:'yellow'
  },
  imge: {
    height: height * 0.06,
    width: width * 0.12,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor:'yellow'
  },
  drop: {
    height: height * 0.06,
    width: width * 0.14,
    justifyContent: "flex-end",
    // backgroundColor:'red'
  },
  imgcon: {
    height: height * 0.06,
    width: width * 0.22,
    flexDirection: "row",
    // backgroundColor:'cyan'
  },
  img1: {
    height: height * 0.06,
    width: width * 0.12,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor:'cyan'
  },
  bimg: {
    height: height * 0.025,
    width: width * 0.37,
    alignItems: "center",
    borderRightWidth: 0.2,
    justifyContent: "center",
    // backgroundColor:'cyan'
  },
  bgimg: {
    height: height * 0.025,
    width: width * 0.12,
    alignItems: "center",
    borderRightWidth: 0.2,
    justifyContent: "center",
    // backgroundColor:'cyan'
  },
  bimg11: {
    height: height * 0.025,
    width: width * 0.12,
    alignItems: "center",
    borderRightWidth: 0.2,
    justifyContent: "center",
    // backgroundColor:'cyan'
  },
  bimg1: {
    height: height * 0.025,
    width: width * 0.12,
    alignItems: "center",
    borderRightWidth: 0.2,
    justifyContent: "center",
    // backgroundColor:'cyan'
  },
  txt: {
    height: height * 0.06,
    width: width * 0.68,
    justifyContent: "center",
    // backgroundColor:'red'
  },
  txtphone: {
    height: height * 0.06,
    width: width * 0.81,
    justifyContent: "center",
    // backgroundColor:'red'
  },
  txtpass: {
    height: height * 0.06,
    width: width * 0.78,
    justifyContent: "center",
    // backgroundColor:'red'
  },
  txtemail: {
    height: height * 0.06,
    width: width * 0.78,
    justifyContent: "center",
    // backgroundColor:'red'
  },
  txt11: {
    height: height * 0.06,
    width: width * 0.78,
    justifyContent: "center",
    // backgroundColor:'red'
  },
  ttx1: {
    height: height * 0.06,
    width: width * 0.74,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'red'
  },
  ttx2: {
    height: height * 0.06,
    width: width * 0.74,
    alignSelf: "center",
    flexDirection: "row",
    justifyContent: "center",
    // backgroundColor:'red'
  },
  img2: {
    height: height * 0.06,
    width: width * 0.1,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'red'
  },
  ttx3: {
    height: height * 0.06,
    width: width * 0.65,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'green'
  },
  fpss: {
    height: height * 0.045,
    width: width * 0.94,
    alignItems: "flex-end",
    alignSelf: "center",
    // backgroundColor:'green'
  },

  fpass: {
    height: height * 0.045,
    width: width * 0.96,
    // alignSelf:'center',
    alignItems: "flex-end",
    justifyContent: "flex-end",
    // backgroundColor:'cyan'
  },
  pass: {
    height: height * 0.05,
    width: width * 1,
    // alignSelf:'center',
    // backgroundColor:'green'
  },
  pss: {
    height: height * 0.05,
    width: width * 0.9,
    justifyContent: "center",
    alignSelf: "center",
    // backgroundColor:'green'
  },
  btncon: {
    height: height * 0.18,
    width: width * 1,
    justifyContent: "center",
    // backgroundColor:'cyan',
  },
  btn: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 7,
    backgroundColor: "#2C723E",
  },
  reg: {
    height: height * 0.06,
    width: width * 1,
    // backgroundColor:"cyan"
  },
  regs: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor:"cyan"
  },
});
