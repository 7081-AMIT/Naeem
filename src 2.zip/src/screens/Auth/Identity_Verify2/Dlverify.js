import {
  StyleSheet,
  Text,
  Image,
  TouchableOpacity,
  View,
  Dimensions,
  SafeAreaView,
} from "react-native";
import React from "react";
import { IMAGEPATH } from "../../../assets/icon";
import * as Progress from "react-native-progress";
import { COLORS } from "../../../utils/Color";

const { height, width } = Dimensions.get("window");
const Dlverify = (props) => {
  return (
    <SafeAreaView>
      <View style={styles.main}>
        <View style={styles.bgcimg}>
          <View style={styles.backimg}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate("Identity")}
            >
              <Image
                style={{ height: 50, width: 50, resizeMode: "contain" }}
                source={IMAGEPATH.AROW_IMAGE}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.crossimg}>
            <TouchableOpacity
              onPress={() => props.navigation.navigate("Identity")}
            >
              <Image
                style={{ height: 15, width: 15, resizeMode: "contain" }}
                source={IMAGEPATH.CROSS_IMAGE}
              />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.text}>
          <Text style={styles.tt1}>Identity Verification</Text>
        </View>
        <View style={styles.imgcon}>
          <Image
            style={{ height: 200, width: 300, resizeMode: "contain" }}
            source={IMAGEPATH.DRIV_IMAGE}
          />
        </View>
        <View style={styles.textt}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "500",
              color: "#000000",
              fontFamily: "Lato-Regular",
            }}
          >
            You are to about to upload your drivign license please ensure that:
          </Text>
        </View>
        <View style={styles.text2}>
          <View style={styles.icon}>
            <Image
              style={{ height: 15, width: 15, resizeMode: "contain" }}
              source={IMAGEPATH.ICON_IMAGE}
            />
          </View>
          <View style={styles.texticon}>
            <Text style={{ fontSize: 16, fontWeight: "400", color: "#8B8B8B" }}>
              This is your government-issue document that is not expired{" "}
            </Text>
          </View>
        </View>
        <View style={styles.lineimg}>
          <Image
            style={{ height: 115, width: 340, resizeMode: "contain" }}
            source={IMAGEPATH.LINE_IMAGE}
          />
        </View>
        <View style={styles.prog}>
          <Progress.Bar
            progress={0.7}
            width={200}
            height={1.8}
            useNativeDriver={true}
            color={"#2C723E"}
            indeterminateAnimationDuration={10}
          />
          {/*<Progress.Pie progress={0.4} size={50} />
          <Progress.Circle size={30} indeterminate={true} />
  <Progress.CircleSnail color={["red", "green", "blue"]} /> */}
        </View>
        <View style={styles.btncon}>
          <TouchableOpacity
            onPress={() => props.navigation.navigate("Identity")}
          >
            <View style={styles.verify}>
              <Text
                style={{ fontSize: 18, color: "#FFFFFF", fontWeight: "700" }}
              >
                Previous
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => props.navigation.navigate("Driver")}>
            <View style={styles.continue}>
              <Text
                style={{ fontSize: 18, color: "#FFFFFF", fontWeight: "700" }}
              >
                Continue
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Dlverify;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
  },
  cross: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "flex-end",
    justifyContent: "center",
    // backgroundColor:'green'
  },
  text: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    //   backgroundColor:'cyan'
  },
  tt1: {
    fontSize: height / 35,
    fontWeight: "600",
    color: "#000000",
    fontFamily: "Lato-Regular",
  },
  prog: {
    height: height * 0.08,
    width: width * 0.9,
    alignItems: "center",
    justifyContent: "flex-end",
    alignSelf: "center",
    // backgroundColor: "green",
  },
  imgcon: {
    height: height * 0.27,
    width: width * 0.9,
    alignItems: "center",
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'cyan'
  },
  textt: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "flex-start",
    //   backgroundColor:'green'
  },
  text2: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    // alignItems:'center',
    justifyContent: "center",
    flexDirection: "row",
    // backgroundColor:'green'
  },
  icon: {
    height: height * 0.04,
    width: width * 0.1,
    justifyContent: "center",

    // backgroundColor:'cyan'
  },
  texticon: {
    height: height * 0.06,
    width: width * 0.8,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'pink'
  },
  lineimg: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'cyan'
  },
  btncon: {
    height: height * 0.12,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    // backgroundColor:'cyan'
  },
  verify: {
    height: height * 0.07,
    width: width * 0.4,
    alignSelf: "center",
    alignItems: "center",
    borderRadius: 7,
    justifyContent: "center",
    backgroundColor: "#7C7C7C",
  },
  continue: {
    height: height * 0.07,
    width: width * 0.4,
    alignItems: "center",
    alignSelf: "center",
    borderRadius: 7,
    justifyContent: "center",
    backgroundColor: "#2C723E",
  },
  bgcimg: {
    height: height * 0.1,
    width: width * 0.95,
    alignSelf: "center",
    alignItems: "center",
    // backgroundColor:'cyan',
    flexDirection: "row",
    justifyContent: "space-between",
  },
  backimg: {
    height: height * 0.05,
    justifyContent: "center",
    alignItems: "flex-start",
    width: width * 0.2,
    // backgroundColor: "cyan",
  },
  crossimg: {
    height: height * 0.05,
    width: width * 0.1,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },
});
