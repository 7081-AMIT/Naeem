import {
  Dimensions,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ImageBackground,
  SafeAreaView,
  TextInput,
  Image,
} from "react-native";
import { Dropdown } from "react-native-material-dropdown";
import React, { useState, useEffect } from "react";
import { COLORS } from "../../../utils/Color";
import { IMAGEPATH } from "../../../assets/icon";
const { height, width } = Dimensions.get("window");

const ForgotPasswordEmail = (props) => {
  const [email, setEmail] = useState("");
  const [errorEmail, setErrorEmail] = useState("");

  const emailValidate = (email) => {
    var Regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email === "" || email === undefined || email === null) {
      setErrorEmail("*please enter email");
    } else if (!Regex.test(email)) {
      setErrorEmail("*Please enter valid email");
    } else {
      setErrorEmail(null);
    }
  };
  const validate = () => {
    var Rgex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    const flag = true;
    if (email === "") {
      setErrorEmail("*please enter email");
      return !flag;
    }
    if (email === "" || email === undefined || email === null) {
      setErrorEmail("*please enter email");
      return !flag;
    }
    if (!Rgex.test(email)) {
      setErrorEmail("*please enter valid email");
      return !flag;
    } else {
      setErrorEmail(null);
    }

    return flag;
  };

  const onSubmit = () => {
    if (validate()) {
      //   alert('Sussessful')
      props.navigation.navigate("PhoneVerificationOtp");
    } else {
      // alert("Something went wrong");
    }
  };

  return (
    <ImageBackground
      source={IMAGEPATH.BACKGROUND_IMAGE}
      style={{ height: height * 1, width: width * 1 }}
    >
      <View style={styles.ImageBackgroundcontainer}>
        <View style={styles.HeaderButton}>
          <TouchableOpacity
            onPress={() => props.navigation.navigate("Login")}
          >
            <Image source={IMAGEPATH.Back_ARROW_IMAGE} />
          </TouchableOpacity>
          <TouchableOpacity
            // onPress={() => props.navigation.navigate("ForgotOtp")}
          >
            <Image source={IMAGEPATH.CROSS_IMAGE} />
          </TouchableOpacity>
        </View>
        <View style={styles.topcontainer}>
          <Text
            style={{
              color: "black",
              fontSize: height / 35,
              fontWeight: "bold",
            }}
          >
            Forgot Password
          </Text>
        </View>
        <View style={styles.topcontainer1}>
          <Text
            style={{
              //   fontSize: height / 45,
              color: "#9E9E9E",
              fontWeight: "bold",
            }}
          >
            Please enter your registered Email Id
          </Text>
        </View>

        <View style={styles.topcontainer2}>
          <Text
            style={{
              fontSize: height / 45,
              fontWeight: "bold",
              color:'black'
            }}
          >
            Email
          </Text>
        </View>

        <View style={styles.TextInputConatiner}>
          <View style={styles.txtInput}>
            <View style={styles.EmailImgV}>
              <Image source={IMAGEPATH.MAIL_IMAGE} />
            </View>
            <View style={styles.txtInput2}>
              <TextInput
                placeholder="Enter your email"
                placeholderTextColor={"#BCBCBC"}
                keyboardType="email-address"
                maxLength={60}
                onChangeText={(text) => {
                  setEmail(text), emailValidate(text);
                }}
              />
            </View>
          </View>
          {errorEmail !== null ? (
            <View
              style={{
                height: "30%",
                width: "90%",
                alignSelf: "center",
                // backgroundColor: 'green',
              }}
            >
              <Text style={{ color: "red", fontSize: 16 }}>{errorEmail}</Text>
            </View>
          ) : null}
        </View>
        <View style={styles.BtnV}>
          <TouchableOpacity onPress={() => onSubmit("")}>
            <View style={styles.NextButton}>
              <Text style={{ color: COLORS.WHITE, fontWeight: "bold" }}>
                Submit
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.DontHaveaccount}>
          <Text style={{fontSize:height/60,color:'black'}}>You haven't any account?</Text>
          <TouchableOpacity
            onPress={() => props.navigation.navigate("Register")}
          >
            <Text
              style={{
                color: COLORS.GREEN_TEXT_COLOR,
                textDecorationLine: "underline",
              }}
            >
              Sign Up
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

export default ForgotPasswordEmail;

const styles = StyleSheet.create({
  ImageBackgroundcontainer: {
    height: height * 1,
    width: width * 1,
    alignItems: "center",
    // backgroundColor: "#E5E5E5",
    // backgroundColor:'white'
  },
  HeaderButton: {
    flexDirection: "row",
    height: height * 0.07,
    width: width * 0.95,
    alignSelf: "center",
    justifyContent: "space-between",
    // backgroundColor: "red",
    alignItems: "center",
  },
  topcontainer: {
    height: height * 0.08,
    width: width * 0.9,
    // backgroundColor: "red",
    justifyContent: "center",
  },
  topcontainer1: {
    height: height * 0.06,
    width: width * 0.8,
    // backgroundColor: "green",
    justifyContent: "center",
  },
  topcontainer2: {
    height: height * 0.06,
    width: width * 0.9,
    // backgroundColor: "yellow",
    justifyContent: "center",
  },
  TextInputConatiner: {
    height: height * 0.09,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "brown",
    // justifyContent: "center",
    alignItems: "center",
  },
  txtInput: {
    height: height * 0.06,
    width: width * 0.9,
    // borderWidth: 1,
    borderRadius: 7,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    // backgroundColor:'red',

    shadowRadius: 5,
    shadowOffset: {
      height: 0.5,
      width: 0.5,
    },
    shadowOpacity: 0.1,
    backgroundColor: "#FFFFFF",
  },
  txtInput2: {
    height: height * 0.05,
    width: width * 0.8,
    // borderWidth: 1,
    flexDirection: "row",
    // padding: 5,
  },
  EmailImgV: {
    height: height * 0.035,
    width: width * 0.1,
    borderRightWidth: 0.5,
    justifyContent: "center",
    alignItems: "center",
    borderColor: COLORS.BORDER_WITH_COLOR,
    borderColor: "#8B8B8B",
    // justifyContent:'center'
    // backgroundColor:'red'
  },
  BtnV: {
    height: height * 0.25,
    width: width * 1,
    // backgroundColor: "red",
    justifyContent: "flex-end",
    alignItems: "center",
  },
  NextButton: {
    height: height * 0.06,
    width: width * 0.9,
    borderRadius: 7,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.BUTTON_BACKGROUND_COLOR,
  },
  DontHaveaccount: {
    height: height * 0.2,
    width: width * 0.9,
    // borderWidth: 1,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
});
