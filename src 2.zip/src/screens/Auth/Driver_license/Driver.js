import {
  StyleSheet,
  SafeAreaView,
  Dimensions,
  TouchableOpacity,
  Image,
  Text,
  View,
} from "react-native";
import React from "react";
import { IMAGEPATH } from "../../../assets/icon";
import { COLORS } from "../../../utils/Color";
import * as Progress from "react-native-progress";

const { height, width } = Dimensions.get("window");
const Driver = (props) => {
  return (
    <SafeAreaView>
      <View style={styles.main}>
      <View style={styles.bgcimg}>
      <View style={styles.backimg}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Dlverify")}
        >
          <Image
            style={{ height: 50, width: 50, resizeMode: "contain" }}
            source={IMAGEPATH.AROW_IMAGE}
          />
        </TouchableOpacity>
      </View>
      <View style={styles.crossimg}>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Identity")}
        >
          <Image
            style={{ height: 15, width: 15, resizeMode: "contain" }}
            source={IMAGEPATH.CROSS_IMAGE}
          />
        </TouchableOpacity>
      </View>
    </View>
        <View style={styles.text}>
          <Text style={styles.tt1}>Identity Verification</Text>
        </View>
        <View style={styles.txt}>
          <Text style={{ fontSize:height/55, fontWeight: "500", color: "#000000" }}>
            Upload your driver license
          </Text>
        </View>
        <View style={styles.txt1}>
          <Text style={{ fontSize:height/58, fontWeight: "400", color: "#000000" }}>
            Front side of Drivign License
          </Text>
        </View>
        <View style={styles.fimg}>
          <Image
            style={{ height: 215, width: 340, resizeMode: "contain" }}
            source={IMAGEPATH.DRIVING_LICENSE_IMAGE}
          />
        </View>

        <View style={styles.txt1}>
          <Text style={{ fontSize:height/58, fontWeight: "400", color: "#000000" }}>
            Front side of Drivign License
          </Text>
        </View>
        <View style={styles.fimg}>
          <Image
            style={{ height: 215, width: 340, resizeMode: "contain" }}
            source={IMAGEPATH.DRIVER_BACK_IMAGE}
          />
        </View>
        <View style={styles.prog}>
          <Progress.Bar
            progress={0.7}
            width={200}
            height={1.8}
            useNativeDriver={true}
            color={"#2C723E"}
            indeterminateAnimationDuration={10}
          />
          {/*<Progress.Pie progress={0.4} size={50} />
      <Progress.Circle size={30} indeterminate={true} />
<Progress.CircleSnail color={["red", "green", "blue"]} /> */}
        </View>
        <View style={styles.btncon}>
  <TouchableOpacity onPress={() =>props.navigation.navigate('Dlverify')}>
  <View style={styles.verify}>
  <Text style={{fontSize:18,color:'#FFFFFF',fontWeight:'700'}}>Previous</Text>
  </View>
  </TouchableOpacity>
 <TouchableOpacity onPress={() =>props.navigation.navigate('Selfie')}>
 <View style={styles.continue}>
 <Text style={{fontSize:18,color:'#FFFFFF',fontWeight:'700'}}>Continue</Text>
 </View>
 </TouchableOpacity>
  </View>
      </View>
    </SafeAreaView>
  );
};

export default Driver;

const styles = StyleSheet.create({
  main: {
    height: height * 1,
    width: width * 1,
  },
  cross: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "flex-end",
    justifyContent: "center",
    // backgroundColor:'green'
  },
  text: {
    height: height * 0.05,
    width: width * 0.9,
    alignSelf: "center",
    //   backgroundColor:'cyan'
  },
  tt1: {
    fontSize: height / 35,
    fontWeight: "600",
    color: "#000000",
    fontFamily: "Lato-Regular",
  },
  txt: {
    height: height * 0.04,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'cyan'
  },
  txt1: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    //   backgroundColor:'cyan'
  },
  fimg: {
    height: height * 0.26,
    width: width * 0.9,
    alignSelf: "center",
    //   backgroundColor:'cyan'
  },
  prog: {
    height: height * 0.015,
    width: width * 0.9,
    alignItems: "center",
    justifyContent: "flex-end",
    alignSelf: "center",
    // backgroundColor: "green",
  },
  btncon:{
    height:height*0.12,
    width:width*0.9,
    alignSelf:'center',
    alignItems:'center',
    justifyContent:'space-between',
    flexDirection:'row',
    // backgroundColor:'cyan'
},
verify:{
    height:height*0.07,
    width:width*0.4,
    alignSelf:'center',
    alignItems:'center',
    borderRadius:7,
    justifyContent:'center',
    backgroundColor:'#7C7C7C'
},
continue:{
    height:height*0.07,
    width:width*0.4,
    alignItems:'center',
    alignSelf:'center',
    borderRadius:7,
    justifyContent:'center',
    backgroundColor:'#2C723E'
},
bgcimg: {
  height: height * 0.07,
  width: width * 0.95,
  alignSelf: "center",
  alignItems: "center",
  // backgroundColor:'cyan',
  flexDirection: "row",
  justifyContent: "space-between",
},
backimg: {
  height: height * 0.05,
  justifyContent: "center",
  alignItems: "flex-start",
  width: width * 0.2,
  // backgroundColor: "cyan",
},
crossimg: {
  height: height * 0.05,
  width: width * 0.1,
  alignItems: "center",
  justifyContent: "center",
  // backgroundColor: "green",
},
});
