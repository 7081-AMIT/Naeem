import {
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Text,
  SafeAreaView,
  View,
} from "react-native";
import React from "react";
import { IMAGEPATH } from "../../../assets/icon";
import { COLORS } from "../../../utils/Color";
import { Dropdown } from "react-native-material-dropdown";
const { height, width } = Dimensions.get("window");
const data = [
  {
    value: "USA",
  },
  {
    value: "UK",
  },
];
const Identity = (props) => {
  return (
    <SafeAreaView>
      <View style={styles.mail}>
        <View style={styles.cross}>
          <TouchableOpacity onPress={() => props.navigation.navigate("Create")}>
            <Image
              style={{ height: 15, width: 15, resizeMode: "contain" }}
              source={IMAGEPATH.CROSS_IMAGE}
            />
          </TouchableOpacity>
        </View>
        <View style={styles.text}>
          <Text style={styles.tt1}>Identity Verification</Text>
        </View>
        <View style={styles.dropcon}>
          <View style={styles.img}>
            <Image
              style={{ height: 30, width: 30, resizeMode: "contain" }}
              source={IMAGEPATH.FLAG_IMAGE}
            />
          </View>
          <View style={styles.drop}>
            <Dropdown label="India" data={data} />
          </View>
        </View>
        <View style={styles.textcon}>
          <View style={styles.tex}>
            <Text
              style={{
                fontSize: 18,
                color: "#000000",
                fontFamily: "Lato-Regular",
                fontWeight: "500",
              }}
            >
              Use a valid government-issue document
            </Text>
          </View>
        </View>
        <View style={styles.text1con}>
          <View style={styles.text1}>
            <Text
              style={{
                fontSize: 16,
                color: "#8B8B8B",
                fontFamily: "Lato-Regular",
              }}
            >
              Only the following documents listed below will be accepted
              documents will be rejected{" "}
            </Text>
          </View>
        </View>
        <View style={styles.adrcon}>
          <View style={styles.adharcon}>
            <View style={styles.adhar}>
              <View style={styles.adhr}>
                <View style={styles.adharimg}>
                  <Image
                    style={{ height: 20, width: 20, resizeMode: "contain" }}
                    source={IMAGEPATH.ADHAR_IMAGE}
                  />
                </View>
                <View style={styles.adrtxt}>
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#343434",
                      fontFamily: "Lato-Regular",
                      fontWeight: "700",
                    }}
                  >
                    Adhar Card
                  </Text>
                </View>
              </View>
            </View>
            <View style={styles.done}>
              <Image
                style={{ height: 20, width: 20, resizeMode: "contain" }}
                source={IMAGEPATH.DONE_IMAGE}
              />
            </View>
          </View>

          <View style={styles.adharcon}>
            <View style={styles.adhar}>
              <View style={styles.adhr}>
                <View style={styles.adharimg}>
                  <Image
                    style={{ height: 20, width: 20, resizeMode: "contain" }}
                    source={IMAGEPATH.BROUSE_IMAGE}
                  />
                </View>
                <View style={styles.adrtxt}>
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#343434",
                      fontFamily: "Lato-Regular",
                      fontWeight: "700",
                    }}
                  >
                    Passport
                  </Text>
                </View>
              </View>
            </View>
            <View style={styles.done}>
              <Image
                style={{ height: 20, width: 20, resizeMode: "contain" }}
                source={IMAGEPATH.DONE_IMAGE}
              />
            </View>
          </View>

          <View style={styles.adharcon}>
            <View style={styles.adhar}>
              <View style={styles.adhr}>
                <View style={styles.adharimg}>
                  <Image
                    style={{ height: 20, width: 20, resizeMode: "contain" }}
                    source={IMAGEPATH.CAR_IMAGE}
                  />
                </View>
                <View style={styles.adrtxt}>
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#343434",
                      fontFamily: "Lato-Regular",
                      fontWeight: "700",
                    }}
                  >
                    Driver's License
                  </Text>
                </View>
              </View>
            </View>
            <View style={styles.done}>
              <Image
                style={{ height: 20, width: 20, resizeMode: "contain" }}
                source={IMAGEPATH.DONE_IMAGE}
              />
            </View>
          </View>
        </View>
        <View style={styles.btncon}>
          <TouchableOpacity onPress={() =>props.navigation.navigate('Dlverify')}>
            <View style={styles.btn}>
              <Text
                style={{
                  fontSize: 19,
                  color: "#FFFFFF",
                  fontWeight: "700",
                  fontFamily: "Lato-Regular",
                }}
              >
                Continue
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Identity;

const styles = StyleSheet.create({
  mail: {
    height: height * 1,
    width: width * 1,
  },
  cross: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "flex-end",
    justifyContent: "center",
    // backgroundColor:'green'
  },
  text: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    //   backgroundColor:'cyan'
  },
  tt1: {
    fontSize: height / 35,
    fontWeight: "600",
    color: "#000000",
    fontFamily: "Lato-Regular",
  },
  drop: {
    height: height * 0.06,
    width: width * 0.75,
    alignSelf: "center",
    justifyContent: "flex-end",
    //   backgroundColor:'green'
  },
  img: {
    height: height * 0.06,
    width: width * 0.15,
    // alignItems:'center',
    justifyContent: "center",
    //   backgroundColor:'cyan'
  },
  dropcon: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    borderWidth: 0.3,
    borderColor: "#8B8B8B",
    flexDirection: "row",
    //   justifyContent:'center'
  },
  textcon: {
    height: height * 0.09,
    width: width * 0.9,
    //   backgroundColor:"cyan",
    alignSelf: "center",
    justifyContent: "center",
  },
  tex: {
    height: height * 0.04,
    width: width * 0.9,
    justifyContent: "center",
    //   backgroundColor:'green'
  },
  text1con: {
    height: height * 0.09,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "flex-start",
    //   backgroundColor:'red'
  },
  text1: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'red'
  },
  adharcon: {
    height: height * 0.07,
    width: width * 0.9,
    alignSelf: "center",
    flexDirection: "row",
    borderRadius: 7,
    backgroundColor: "#FFFFFF",
  },
  adhar: {
    height: height * 0.06,
    width: width * 0.75,
    // backgroundColor:'cyan',
    alignSelf: "center",
  },
  done: {
    height: height * 0.06,
    width: width * 0.15,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    // backgroundColor:'red',
  },
  adhr: {
    height: height * 0.06,
    width: width * 0.6,
    flexDirection: "row",
    // backgroundColor:'yellow'
  },
  adharimg: {
    height: height * 0.06,
    width: width * 0.2,
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor:'white'
  },
  adrtxt: {
    height: height * 0.06,
    width: width * 0.38,
    // alignItems: "center",
    justifyContent: "center",
    // backgroundColor:'blue'
  },
  adrcon: {
    height: height * 0.24,
    width: width * 1,
    // alignSelf:'center',
    // backgroundColor:'cyan',
    justifyContent: "space-between",
  },
  btncon: {
    height: height * 0.2,
    width: width * 1,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor:'green',
  },
  btn: {
    height: height * 0.07,
    width: width * 0.9,
    justifyContent: "center",
    borderRadius: 7,
    alignItems: "center",
    alignSelf: "center",
    backgroundColor: "#2C723E",
  },
});
