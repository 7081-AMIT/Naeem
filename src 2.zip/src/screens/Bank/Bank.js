import {
  Dimensions,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Image,
  SafeAreaView,
  Modal,
} from "react-native";
import { Dropdown } from "react-native-material-dropdown";
import React, { useState, useEffect } from "react";
import { COLORS } from "../../utils/Color";
import { IMAGEPATH } from "../../assets/icon";
import { Colors } from "react-native/Libraries/NewAppScreen";
const { height, width } = Dimensions.get("window");

const Bank = (props) => {
  const [modalVisible, setModalVisible] = useState(false);

  //***** Validation */

  const [name, setName] = useState("");
  const [errorName, setErrorName] = useState("");

  const [account, setAccount] = useState("");
  const [erroraccount, setErrorAccount] = useState("");

  const [bankname, setBankname] = useState("");
  const [errorBankname, setErrorBankname] = useState("");

  //   ****** validate perticular  validate ****//
  const nameValidate = (name) => {
    var nameRegex = /^[a-zA-Z ]{2,30}$/;
    if (name === "" || name === undefined || name === null) {
      setErrorName("please enter name");
    } else if (!nameRegex.test(name)) {
      setErrorName("please enter full name");
    } else {
      setErrorName(null);
    }
  };

  // account number

  const accountValidate = (account) => {
    var accountRegex = /^([0-9]{10})|([0-9]{3}-[0-9]{3})$/;
    if (account === "" || account === undefined || account === null) {
      setErrorAccount("please enter account number");
    } else if (!accountRegex.test(account)) {
      setErrorAccount("please enter valid account number");
    } else {
      setErrorAccount(null);
    }
  };

  //   **** account holder name

  const banknameValidate = (bankname) => {
    var banknameRegex = /^[a-zA-Z ]{2,30}$/;
    if (bankname === "" || bankname === undefined || bankname === null) {
      setErrorBankname("please enter account holder name");
    } else if (!banknameRegex.test(bankname)) {
      setErrorBankname("please enter full account holder  name");
    } else {
      setErrorBankname(null);
    }
  };

  // IFSC CODE

  // valdate Every funciton//
  const validate = () => {
    var nameRegex = /^[a-zA-Z ]{2,30}$/;
    var accountRegex = /^([0-9]{10})|([0-9]{3}-[0-9]{3})$/;
    var codeRegex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
    var banknameRegex = /^[a-zA-Z ]{2,30}$/;

    const flag = true;

    if (name === "") {
      setErrorName("*please enter name");
      return !flag;
    }
    if (name === "" || name === undefined || name === null) {
      setErrorName("*Please enter name");
      return !flag;
    }
    if (!nameRegex.test(name)) {
      setErrorName("*Please enter full name");
      return !flag;
    } else setErrorName(null);

    // **** account***//
    if (account === "") {
      setErrorAccount("*please enter account number");
      return !flag;
    }
    if (account === "" || account === undefined || account === null) {
      setErrorAccount("*Please enter account");
      return !flag;
    }
    if (!accountRegex.test(name)) {
      setErrorAccount("*Please enter valid account number");
      return !flag;
    } else setErrorAccount(null);

    // ******* account holder****

    if (bankname === "") {
      setErrorBankname("*please enter account holder name");
      return !flag;
    }
    if (bankname === "" || bankname === undefined || bankname === null) {
      setErrorBankname("*Please enter account holder name");
      return !flag;
    }
    if (!banknameRegex.test(bankname)) {
      setErrorBankname("*Please enter valid account holder name");
      return !flag;
    } else setErrorBankname(null);

    // **** IFSC CODE ****

    return flag;
  };

  //   **** IFSC CODE *****//

  //   ****** ON Submit *******//

  const onSubmit = () => {
    if (validate()) {
      // alert('Sussessful')
      props.navigation.navigate("AddBankAccount");
    } else {
      alert("Something went wrong");
    }
  };

  return (
    <View style={styles.ImageBackgroundcontainer}>
      <View style={styles.HeaderButton}>
        <TouchableOpacity onPress={() => props.navigation.navigate("Register")}>
          <View style={styles.arrowV}>
            <Image source={IMAGEPATH.Back_ARROW_IMAGE} />
          </View>
        </TouchableOpacity>
        <View style={styles.tital}>
          <Text
            style={{
              fontSize: height / 38,
              fontWeight: "bold",
              color: COLORS.BLACK_TEXT_COLOR,
            }}
          >
            Settings
          </Text>
        </View>
      </View>

      <View style={styles.mainImgV}>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.BANK_USER_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.BANK_SETTING_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.USER_INFO_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setModalVisible(true)}>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.BANK_IMAGE} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity>
          <View style={styles.Image}>
            <View style={{ position: "absolute" }}>
              <Image source={IMAGEPATH.CIRCLE_IMAGE} />
            </View>
            <Image source={IMAGEPATH.ADDUSER_IMAGE} />
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.topcontainer}>
        <TouchableOpacity>
          <Text
            style={{
              color: "black",
              fontSize: height / 45,
              fontWeight: "bold",
              textDecorationLine: "underline",
              color: COLORS.GREEN_TEXT_COLOR,
              //   fontFamily: "Lato",
            }}
          >
            Saved Bank
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.AddBank}>
        <View style={styles.saveMoney}>
          <Image source={IMAGEPATH.SAVE_MONEY_IMAGE} />
        </View>
        <View>
          <Text> No Bank Added</Text>
        </View>
      </View>

      <View>
        <Modal animationType="slide" transparent={true} visible={modalVisible}>
          <SafeAreaView>
            <View style={styles.Modal}>
              <View style={styles.ModalBottomV}>
                <View style={styles.ModalHeader}>
                  <View style={styles.ModalTital}>
                    <Text
                      style={{
                        fontWeight: "bold",
                        color: COLORS.BLACK_TEXT_COLOR,
                      }}
                    >
                      Add Bank
                    </Text>
                    <TouchableOpacity
                      onPress={() => setModalVisible(!modalVisible)}
                    >
                      <Image source={IMAGEPATH.CROSS_GREEN} />
                    </TouchableOpacity>
                  </View>
                </View>
                <View style={styles.upper}></View>
                <View style={styles.modaladdbank}>
                  <View style={styles.txtInput}>
                    <View style={styles.textInputFeild}>
                      <TextInput
                        placeholder="Bank Name"
                        minLength={5}
                        maxLength={30}
                        onChangeText={(text) => {
                          setName(text), nameValidate(text);
                        }}
                      />
                    </View>
                  </View>
                  {errorName !== null ? (
                    <View
                      style={{
                        height: "30%",
                        width: "80%",
                        // alignSelf:'center',
                        // backgroundColor: "skyblue",
                      }}
                    >
                      <Text style={{ color: "red", fontSize: 16 }}>
                        {errorName}
                      </Text>
                    </View>
                  ) : null}
                </View>

                <View style={styles.modaladdbank}>
                  <View style={styles.txtInput}>
                    <View style={styles.textInputFeild}>
                      <TextInput
                        placeholder="Account Number"
                        maxLength={16}
                        onChangeText={(text) => {
                          setAccount(text), accountValidate(text);
                        }}
                      />
                    </View>
                  </View>
                  {erroraccount !== null ? (
                    <View
                      style={{
                        height: "30%",
                        width: "80%",
                        // alignSelf:'center',
                        // backgroundColor: "skyblue",
                      }}
                    >
                      <Text style={{ color: "red", fontSize: 16 }}>
                        {erroraccount}
                      </Text>
                    </View>
                  ) : null}
                </View>

                <View style={styles.modaladdbank}>
                  <View style={styles.txtInput}>
                    <View style={styles.textInputFeild}>
                      <TextInput
                        placeholder="Account Holder Name"
                        maxLength={30}
                        onChangeText={(text) => {
                          setBankname(text), banknameValidate(text);
                        }}
                      />
                    </View>
                  </View>
                  {errorBankname !== null ? (
                    <View
                      style={{
                        height: "30%",
                        width: "80%",
                        // alignSelf:'center',
                        // backgroundColor: "skyblue",
                      }}
                    >
                      <Text style={{ color: "red", fontSize: 16 }}>
                        {errorBankname}
                      </Text>
                    </View>
                  ) : null}
                </View>

                <View style={styles.modaladdbank}>
                  <View style={styles.txtInput}>
                    <View style={styles.textInputFeild}>
                      <TextInput placeholder="IFSC Code" maxLength={11} />
                    </View>
                  </View>
                </View>

                <TouchableOpacity onPress={() => onSubmit("")}>
                  <View style={styles.Btn}>
                    <View style={styles.Confirm}>
                      <Text style={{ color: COLORS.WHITE, fontWeight: "bold" }}>
                        CONFIRM
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </SafeAreaView>
        </Modal>
      </View>
    </View>
  );
};

export default Bank;

const styles = StyleSheet.create({
  ImageBackgroundcontainer: {
    height: height * 1,
    width: width * 1,
    alignItems: "center",
    // backgroundColor: "#E5E5E5",
    // backgroundColor:'skyblue'
  },
  HeaderButton: {
    flexDirection: "row",
    height: height * 0.07,
    width: width * 0.98,
    alignSelf: "center",
    // backgroundColor: "red",
  },

  topcontainer: {
    height: height * 0.06,
    width: width * 0.9,
    // backgroundColor: "pink",
    //justifyContent:'center',
    alignItems: "center",
    flexDirection: "row",
  },

  textcontainer: {
    height: height * 0.1,
    width: width * 0.7,
    //backgroundColor:'green',
    justifyContent: "center",
    alignItems: "center",
    // fontFamily: "Lato",
  },
  arrowV: {
    height: height * 0.07,
    width: width * 0.15,
    // backgroundColor: "green",
  },

  tital: {
    height: height * 0.07,
    width: width * 0.6,
    // backgroundColor: "yellow",
    fontFamily: "Lato",
    justifyContent: "center",
  },
  mainImgV: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "cyan",
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
  },
  Image: {
    height: height * 0.07,
    width: width * 0.15,
    // backgroundColor: "red",
    justifyContent: "center",
    alignItems: "center",
  },
  AddBank: {
    height: height * 0.5,
    width: width * 0.9,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    // borderWidth: 1,
  },
  saveMoney: {
    height: height * 0.11,
    width: width * 0.4,
    // backgroundColor: "red",
    alignItems: "center",
    justifyContent: "center",
  },

  Btn: {
    height: height * 0.09,
    width: width * 1,
    // borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  Confirm: {
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
    height: height * 0.07,
    width: width * 0.9,
    borderRadius: 7,
    // borderWidth: 1,
    backgroundColor: COLORS.BUTTON_BACKGROUND_COLOR,
    // fontFamily: "Lato",
  },
  //   *** modal**
  Modal: {
    height: height * 1,
    width: width * 1,
    // backgroundColor:'skyblue',
    backgroundColor: "rgba(0, 0, 0, 0.69)",
    justifyContent: "flex-end",
  },
  ModalBottomV: {
    height: height * 0.57,
    width: width * 1,
    borderTopRightRadius: 30,
    borderTopLeftRadius: 30,
    backgroundColor: "white",
    alignSelf: "center",
  },
  ModalHeader: {
    height: height * 0.06,
    width: width * 1,
    borderTopRightRadius: 30,
    borderTopLeftRadius: 30,
    borderBottomWidth: 0.6,
    borderColor: COLORS.BORDERWITHCOLOR,
  },
  ModalTital: {
    height: height * 0.06,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "red",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    fontFamily: "Lato",
  },
  upper: {
    height: height * 0.016,
    width: width * 1,
    // borderWidth: 1,
  },
  textInputFeild: {
    // height: height * 0.05,
    width: width * 0.75,
    // backgroundColor: "yellow",
    // justifyContent: "center",
    borderLeftWidth: 0.2,
    color: COLORS.BORDER_WITH_COLOR,
    // padding
  },
  modaladdbank: {
    height: height * 0.09,
    width: width * 1,
    // borderWidth: 1,
    // justifyContent: "center",
    alignItems: "center",
  },
  txtInput: {
    height: height * 0.06,
    width: width * 0.9,
    borderWidth: 0.5,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 7,

    borderColor: "rgb( 204,198,204)",
    shadowColor: "#000000",
    shadowRadius: 5,
    shadowOffset: {
      height: 0.5,
      width: 0.5,
    },
    shadowOpacity: 0.1,
    backgroundColor: "#FFFFFF",
  },
});

// ^[A-Z]{4}0[A-Z0-9]{6}$ regex for ifsc code
