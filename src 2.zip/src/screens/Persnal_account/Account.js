import {
    StyleSheet,
    Text,
    SafeAreaView,
    TouchableOpacity,
    Image,
    Dimensions,
    View,
  } from "react-native";
  import React from "react";
  import { IMAGEPATH } from "../../assets/icon";
  import { COLORS } from "../../utils/Color";
  const { height, width } = Dimensions.get("window");
  
  const Account = (props) => {
    return (
      <SafeAreaView>
        <View style={styles.main}>
          <View style={styles.bgcimg}>
            <View style={styles.backimg}>
              <TouchableOpacity
                onPress={() => props.navigation.navigate("Login")}
              >
                <Image
                  style={{ height: 50, width: 50, resizeMode: "contain" }}
                  source={IMAGEPATH.AROW_IMAGE}
                />
              </TouchableOpacity>
            </View>
            <View style={styles.crossimg}>
              <TouchableOpacity
                onPress={() => props.navigation.navigate("Phone")}
              >
                <Image
                  style={{ height: 15, width: 15, resizeMode: "contain" }}
                  source={IMAGEPATH.CROSS_IMAGE}
                />
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.createcon}>
            <Text
              style={{
                fontSize: 28,
                fontWeight: "600",
                color: "#000000",
                fontFamily: "Lato-Regular",
              }}
            >
              Create Your Account
            </Text>
          </View>
          <View style={styles.xtxcon}>
            <View style={styles.text}>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "400",
                  color: "#343434",
                  fontFamily: "Lato-Regular",
                }}
              >
                Company is the world's largest crypto exchange platform
              </Text>
            </View>
          </View>
          <View style={styles.container}>
            <View style={styles.createco}>
              <View style={styles.imcon}>
                <View style={styles.img}>
                  <Image
                    style={{ height: 20, width: 20, resizeMode: "contain" }}
                    source={IMAGEPATH.USER_IMAGE}
                  />
                </View>
                <View style={styles.ttx}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontFamily: "Lato-Regular",
                      fontWeight: "500",
                      color: "#343434",
                    }}
                  >
                    Create Account
                  </Text>
                </View>
              </View>
              <View style={styles.acdtl}>
                <Text
                  style={{
                    fontSize: 14,
                    fontFamily: "Lato-Regular",
                    fontWeight: "400",
                    color: "#8B8B8B",
                  }}
                >
                  Enter your account details.
                </Text>
              </View>
            </View>
  
            <View style={styles.createco}>
              <View style={styles.imcon}>
                <View style={styles.img}>
                  <Image
                    style={{ height: 20, width: 20, resizeMode: "contain" }}
                    source={IMAGEPATH.IDENTITY_IMAGE}
                  />
                </View>
                <View style={styles.ttx}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontFamily: "Lato-Regular",
                      fontWeight: "500",
                      color: "#343434",
                    }}
                  >
                    Verify Identity
                  </Text>
                </View>
              </View>
              <View style={styles.acdtl}>
                <Text
                  style={{
                    fontSize: height/60,
                    fontFamily: "Lato-Regular",
                    fontWeight: "400",
                    color: "#8B8B8B",
                  }}
                >
                  Verify your identity to protect your account
                </Text>
              </View>
            </View>
  
            <View style={styles.createco}>
              <View style={styles.imcon}>
                <View style={styles.img}>
                  <Image
                    style={{ height: 20, width: 20, resizeMode: "contain" }}
                    source={IMAGEPATH.LOCK_PRICE_IMAGE}
                  />
                </View>
                <View style={styles.ttx}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontFamily: "Lato-Regular",
                      fontWeight: "500",
                      color: "#343434",
                    }}
                  >
                    Unlock Price
                  </Text>
                </View>
              </View>
              <View style={styles.acdtl}>
                <Text
                  style={{
                    fontSize: 14,
                    fontFamily: "Lato-Regular",
                    fontWeight: "400",
                    color: "#8B8B8B",
                  }}
                >
                  Get your price and start trading
                </Text>
              </View>
            </View>
          </View>
          <View style={styles.txttcon}>
          <View style={{flexDirection:'row'}}>
          <View style={{height:height*0.028,
        width:width*0.67,}}>
          <Text style={{color:'#8B8B8B'}}>By creating an account you agree to our </Text>
          </View>
          <View style={{height:height*0.028,
            width:width*0.18,}}>
          <Text style={{color:"green"}}>Terms and </Text>
          </View>
          <View>
          </View>
          </View>
          <View style={{flexDirection:'row'}}>
          <View style={{height:height*0.028,
            width:width*0.18,}}>
          <Text style={{color:'green'}}> Condition </Text>
          </View>
          <View style={{height:height*0.028,
            width:width*0.08,}}>
          <Text style={{color:'#8B8B8B'}}>and </Text>
          </View>
          <View style={{height:height*0.028,
            width:width*0.45,}}>
         <TouchableOpacity>
         <Text style={{color:"green",fontSize:height/60}}>Data Protection Guidelines.</Text>
         </TouchableOpacity>
          </View>
          </View>
          </View>
          <View style={styles.btncon}>
            <TouchableOpacity onPress={() =>props.navigation.navigate('Register')}>
              <View style={styles.btn}>
                <Text
                  style={{ fontSize:height/60, color: "#FFFFFF", fontWeight: "700" }}
                >
                  Create Personal Account
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={styles.logcon}>
          <View >
          <Text style={{fontSize:18,color:'#343434'}}>Already registered?</Text>
          </View>
          <View style={styles.log}>
         <TouchableOpacity onPress={() =>props.navigation.navigate('Login')}>
         <Text style={{fontSize:height/50,color:"green",}}> Log in </Text>
         </TouchableOpacity>
          </View>
          </View>
        </View>
      </SafeAreaView>
    );
  };
  
  export default Account;
  
  const styles = StyleSheet.create({
    main: {
      height: height * 1,
      width: width * 1,
    },
    bgcimg: {
      height: height * 0.1,
      width: width * 0.95,
      alignSelf: "center",
      alignItems: "center",
      // backgroundColor:'cyan',
      flexDirection: "row",
      justifyContent: "space-between",
    },
    backimg: {
      height: height * 0.05,
      justifyContent: "center",
      alignItems: "flex-start",
      width: width * 0.2,
      // backgroundColor: "cyan",
    },
    crossimg: {
      height: height * 0.05,
      width: width * 0.1,
      alignItems: "center",
      justifyContent: "center",
      // backgroundColor: "green",
    },
    createcon: {
      height: height * 0.056,
      width: width * 0.9,
      alignSelf: "center",
      justifyContent: "center",
      // backgroundColor:'cyan'
    },
    text: {
      height: height * 0.05,
      width: width * 0.8,
      //   alignSelf:'center',
      //   backgroundColor:'cyan'
    },
    xtxcon: {
      height: height * 0.05,
      width: width * 0.9,
      alignSelf: "center",
      // backgroundColor:'cyan'
    },
    container: {
      height: height * 0.3,
      width: width * 0.9,
      alignSelf: "center",
      justifyContent: "space-evenly",
      // backgroundColor:"cyan"
    },
    createco: {
      height: height * 0.08,
      width: width * 0.9,
      // backgroundColor:'green',
    },
    imcon: {
      height: height * 0.05,
      width: width * 0.9,
      flexDirection: "row",
      // backgroundColor:'pink'
    },
    img: {
      height: height * 0.05,
      width: width * 0.1,
      justifyContent: "center",
      // backgroundColor:'cyan'
    },
    ttx: {
      height: height * 0.05,
      width: width * 0.8,
      justifyContent: "center",
      // backgroundColor:'blue'
    },
    acdtl: {
      height: height * 0.03,
      width: width * 0.72,
      alignSelf: "center",
      // backgroundColor:'pink'
    },
    btncon: {
      height: height * 0.1,
      width: width * 0.9,
      justifyContent: "center",
      alignSelf: "center",
      // backgroundColor:'cyan'   
    },
    btn: {
      height: height * 0.06,
      width: width * 0.9,
      borderRadius: 7,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: "#2C723E",
    },
    txttcon:{
        height:height*0.12,
        width:width*0.9,
        alignSelf:'center',
        // flexDirection:'row-reverse',
        // backgroundColor:'cyan'
    },logcon:{
        height:height*0.1,
        width:width*0.9,
        alignSelf:'center',
        alignItems:'center',
        justifyContent:'center',
        flexDirection:"row",
        // backgroundColor:"cyan"
    },
    log:{
        height:height*0.029,
        width:width*0.14,
        borderBottomWidth:0.4,
        borderColor:"green",
        // backgroundColor:'cyan'
    }
  });
  